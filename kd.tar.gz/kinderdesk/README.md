# KinderDesk — bog'chalar uchun CRM (SaaS)

Bitta platforma, ko'p bog'cha (single-DB multi-tenancy, subdomen yo'q). Laravel 13 · PHP 8.3 · MySQL · Blade + Alpine + Tailwind v4 · Reverb (real-time).

> **PHP versiyasi:** PHP 8.2 da `composer install` avtomatik Laravel 12 ni, PHP 8.3+ da Laravel 13 ni o'rnatadi. Kod ikkalasida ishlaydi.

> **Eslatma:** loyiha mahalliy muhitda Laravel 12.52 bilan sinovdan o'tgan (11 ta test yashil, barcha sahifalar 200). `composer.json` Laravel 13 ni talab qiladi — `composer install`da xato chiqsa, xabarini yuboring.

## O'rnatish (Windows + XAMPP)
1. XAMPP'da Apache va MySQL ni yoqing, phpMyAdmin'da `kinderdesk` bazasini yarating (utf8mb4_unicode_ci).
2. Shu papkada:
   ```
   composer install
   copy .env.example .env
   php artisan key:generate
   php artisan migrate --seed
   php artisan storage:link
   npm install
   npm run build
   ```
3. Ishga tushirish: `composer dev` (server + navbat + jadval + Reverb) yoki alohida:
   `php artisan serve`, `php artisan queue:work`, `php artisan schedule:work`, `php artisan reverb:start`.
   Reverb ishlamasa tizim avtomatik 20 soniyalik "polling"ga o'tadi.
4. Productionda cron: `* * * * * php artisan schedule:run`

## Kirish
- Super admin: `998901112233` / `ChangeMe!2026` (**darhol almashtiring**) — `/admin`
- Namunaviy bog'cha: `php artisan kd:demo` → **998900000001** / `Demo12345`
- `SMS_DRIVER=log` va `APP_DEBUG=true` bo'lsa OTP kodi sahifada ko'rinadi. Haqiqiy SMS uchun `.env` va Admin → Sozlamalar'da Eskiz ma'lumotlarini kiriting.

## Asosiy qoidalar
14 kunlik sinov → so'ng faqat ko'rish; 1/3/12 oylik tariflar; Payme yoki karta + chek (tasdiqlanganda to'liq summa balansga); tugashiga 3 kun qolganda ogohlantirish; tugaganda balansdan avtomatik yechish; 90 kundan keyin o'chirish xabari (o'chirish faqat qo'lda, qaytarib bo'lmaydi); telefon/email/STIR bilan ikkinchi sinov berilmaydi.

## Tekshirish kerak bo'lgan joylar
- Narxlar — vaqtincha (Admin → Tariflar).
- Eskiz shablon holati maydoni va Payme sandbox — oflayn tekshirib bo'lmadi, o'z hisobingiz bilan sinang.
- Yuridik matnlar (oferta, maxfiylik) va soliq ma'lumotlari — o'zingiz tasdiqlang.
- Rus tili hozircha yo'q (tarjima fayli yozilmagan).
- Logotip PNG'larida shaxmat fon bor edi, shuning uchun logo SVG qilib qayta chizilgan.

## Testlar
`php artisan test`

## Yangilanishlar (v2)

- **Til:** asosiy til — rus (`APP_LOCALE=ru`), ikkinchisi — o'zbek. Tilni almashtirish: yuqoridagi `RU | UZ` tugmasi. Tarjimalar: `lang/ru.json` (kalit — o'zbekcha matn). Yangi matn qo'shgach: `php artisan kd:i18n --missing`.
- **Lavozimlar:** Sozlamalar → Lavozimlar. Direktor lavozim yaratadi va har bir ruxsatni belgilaydi.
- **Kassa va Moliya:** Kassa — kunlik tushum (kassir). Pul direktorga "topshirish" so'rovi bilan o'tadi; direktor Moliya bo'limida tasdiqlaydi yoki rad etadi.
- **Kechki va shanba guruhlari:** davomadda "keldi" belgilangan kun uchun kunlik narx yechiladi.
- **To'garaklar:** alohida to'lov (oylik yoki mashg'ulot uchun).
- **Server holati (super admin):** `/admin/tizim` — real vaqtda.
- **Yo'riqnoma:** `/app/yoriqnoma` (RU va UZ).

### Ishga tushirish
```
composer install && npm install && npm run build
php artisan migrate:fresh --seed
php artisan kd:demo            # namuna ma'lumot (ixtiyoriy)
php artisan serve
php artisan queue:work         # alohida oynada
php artisan schedule:work      # alohida oynada
```
`.env`: `DB_PASSWORD=...`, `SMS_DRIVER=log` (Eskiz shablonlari tasdiqlanguncha), `BROADCAST_CONNECTION=log`, `APP_LOCALE=ru`.
