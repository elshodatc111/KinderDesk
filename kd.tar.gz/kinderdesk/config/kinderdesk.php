<?php

/*
|--------------------------------------------------------------------------
| KinderDesk — platforma sozlamalari reyestri
|--------------------------------------------------------------------------
| Bu fayl platformaning "miyasi": xususiyatlar (features), ruxsatlar,
| bog'cha sozlamalari, SMS hodisalari va nashrlar (editions) shu yerda
| ro'yxatdan o'tadi. Yangi imkoniyat qo'shish uchun shu yerga yozing.
*/

return [

    /* ---------------- Obuna va hayotiy sikl ---------------- */
    'trial_days' => (int) env('KD_TRIAL_DAYS', 14),
    'reminder_days' => (int) env('KD_REMINDER_DAYS', 3),
    'delete_after_days' => (int) env('KD_DELETE_AFTER_DAYS', 90),

    // Super admin (seeder uchun)
    'superadmin' => [
        'name' => env('KD_SUPERADMIN_NAME', 'Super Admin'),
        'phone' => env('KD_SUPERADMIN_PHONE', '998901112233'),
        'password' => env('KD_SUPERADMIN_PASSWORD', 'ChangeMe!2026'),
    ],

    /* ---------------- Telefon / OTP ---------------- */
    'otp' => [
        'length' => 6,
        'ttl_minutes' => 5,
        'max_attempts' => 5,
        'resend_seconds' => 60,
        // SMS_DRIVER=log bo'lsa, kod storage/logs ichiga yoziladi (mahalliy sinov uchun)
        'allow_otp_login' => true,
    ],

    /* ---------------- Xususiyatlar (feature flags) ----------------
     | group: menyu/sozlamalarda guruhlash uchun
     | core:  doim yoqiq, o'chirib bo'lmaydi
     */
    'features' => [
        'kids' => ['label' => 'Bolalar', 'desc' => "Bolalar ro'yxati, ota-ona ma'lumotlari, arxiv", 'group' => 'Asosiy', 'core' => true],
        'groups' => ['label' => 'Guruhlar', 'desc' => "Guruhlar, bola va tarbiyachi biriktirish tarixi", 'group' => 'Asosiy', 'core' => true],
        'employees' => ['label' => 'Xodimlar', 'desc' => "Xodimlar kartasi va tizimga kirish huquqi", 'group' => 'Asosiy', 'core' => true],
        'attendance' => ['label' => 'Bolalar davomadi', 'desc' => "Guruh bo'yicha kunlik davomad", 'group' => 'Asosiy'],
        'staff_attendance' => ['label' => 'Xodimlar davomadi', 'desc' => "Xodimlarning kunlik kelish-ketishi", 'group' => 'Asosiy'],
        'finance' => ['label' => 'Moliya', 'desc' => "Direktor moliyasi: kirim, xarajat, hisoblar o'rtasida o'tkazma", 'group' => 'Moliya'],
        'desk' => ['label' => 'Kassa', 'desc' => "Bog'cha kassasi: ota-onalardan to'lov qabul qilish va direktorga pul topshirish", 'group' => 'Moliya'],
        'clubs' => ['label' => "To'garaklar", 'desc' => "Alohida to'garaklar: a'zolik, davomad va alohida to'lov", 'group' => 'Asosiy'],
        'extra_groups' => ['label' => 'Shanba va kechki guruhlar', 'desc' => "Shanba guruhi va kechki guruh (17:00–20:00): faqat kelgan kun uchun to'lov", 'group' => 'Asosiy'],
        'payroll' => ['label' => 'Ish haqi', 'desc' => "Oylik ish haqi hisob-kitobi va to'lovi", 'group' => 'Moliya'],
        'leads' => ['label' => 'Arizalar (leadlar)', 'desc' => "Bola va xodim arizalari, voronka, ochiq forma", 'group' => 'Qabul'],
        'sms' => ['label' => 'SMS xabarlar', 'desc' => "Ota-onalarga SMS: o'z Eskiz akkaunti, shablonlar, qoidalar", 'group' => 'Aloqa'],
        'reports' => ['label' => 'Hisobotlar', 'desc' => "Bolalar, to'lovlar, qarzdorlar va boshqa hisobotlar", 'group' => 'Tahlil'],
        'analytics' => ['label' => 'Jonli statistika', 'desc' => "Dashboard grafiklari va real-time ko'rsatkichlar", 'group' => 'Tahlil'],
        'exports' => ['label' => 'Excel (CSV) eksport', 'desc' => "Hisobotlarni CSV faylga yuklab olish", 'group' => 'Tahlil'],
        'custom_roles' => ['label' => "Lavozimlar va ruxsatlar", 'desc' => "O'z lavozimlaringizni yaratish va har biriga ruxsatlarni sozlash", 'group' => 'Xavfsizlik'],
        'billing_prorate' => ['label' => "Oy o'rtasida kelganlar uchun proporsional to'lov", 'desc' => "Bola oy o'rtasida kirsa, to'lov kunlarga qarab hisoblanadi", 'group' => 'Moliya'],
        'billing_per_day' => ['label' => "Kunlik hisob (davomadga qarab)", 'desc' => "To'lov faqat kelgan kunlar uchun hisoblanadi", 'group' => 'Moliya'],
        'payroll_attendance' => ['label' => "Davomadga qarab maosh", 'desc' => "Maosh ishlagan kunlarga qarab hisoblanadi", 'group' => 'Moliya'],
        'payroll_hybrid' => ['label' => "Aralash maosh (belgilangan + KPI)", 'desc' => "Asosiy maosh + bola soniga qarab qo'shimcha", 'group' => 'Moliya'],
    ],

    /* ---------------- Nashrlar (editions) ---------------- */
    'editions' => [
        'start' => [
            'name' => 'Start',
            'tagline' => "Kichik va oilaviy bog'chalar uchun",
            'color' => 'sky',
            'features' => ['kids', 'groups', 'employees', 'attendance', 'finance', 'desk', 'reports', 'analytics', 'custom_roles'],
            'defaults' => ['billing.mode' => 'monthly_fixed', 'payroll.strategy' => 'fixed', 'finance.require_confirmation' => false],
        ],
        'standard' => [
            'name' => 'Standard',
            'tagline' => "Oddiy xususiy bog'cha uchun to'liq CRM",
            'color' => 'teal',
            'features' => ['kids', 'groups', 'employees', 'attendance', 'staff_attendance', 'finance', 'desk', 'clubs', 'extra_groups', 'payroll', 'leads', 'sms', 'reports', 'analytics', 'exports', 'custom_roles', 'billing_prorate', 'payroll_attendance'],
            'defaults' => ['billing.mode' => 'prorated', 'payroll.strategy' => 'attendance', 'finance.require_confirmation' => true],
        ],
        'premium' => [
            'name' => 'Premium',
            'tagline' => "Katta va tarmoq bog'chalar uchun aralash hisob-kitob",
            'color' => 'sun',
            'features' => ['kids', 'groups', 'employees', 'attendance', 'staff_attendance', 'finance', 'desk', 'clubs', 'extra_groups', 'payroll', 'leads', 'sms', 'reports', 'analytics', 'exports', 'custom_roles', 'billing_prorate', 'billing_per_day', 'payroll_attendance', 'payroll_hybrid'],
            'defaults' => ['billing.mode' => 'prorated', 'payroll.strategy' => 'hybrid', 'finance.require_confirmation' => true],
        ],
    ],

    // Tariflar (muddat oylarda). Narxlar super admin panelida tahrirlanadi;
    // bu qiymatlar faqat boshlang'ich (seed) uchun — haqiqiy narxni o'zingiz belgilang.
    'plan_months' => [1, 3, 12],
    'seed_prices' => [
        'start' => [1 => 79000, 3 => 219000, 12 => 790000],
        'standard' => [1 => 149000, 3 => 399000, 12 => 1490000],
        'premium' => [1 => 299000, 3 => 799000, 12 => 2990000],
    ],

    /* ---------------- Ruxsatlar ---------------- */
    'permissions' => [
        'kids.view' => "Bolalarni ko'rish",
        'kids.manage' => "Bolalarni qo'shish/tahrirlash/arxivlash",
        'groups.view' => "Guruhlarni ko'rish",
        'groups.manage' => "Guruhlarni boshqarish",
        'attendance.kids' => "Bolalar davomadini belgilash",
        'attendance.staff' => "Xodimlar davomadini belgilash",
        'employees.view' => "Xodimlarni ko'rish",
        'employees.manage' => "Xodimlarni boshqarish",
        'leads.view' => "Arizalarni ko'rish",
        'leads.manage' => "Arizalarni boshqarish",
        'clubs.view' => "To'garaklarni ko'rish",
        'clubs.manage' => "To'garaklarni boshqarish",
        'desk.view' => "Kassani ko'rish",
        'finance.payments' => "Kassa: to'lov qabul qilish va qaytarish",
        'desk.handover' => "Kassadan direktorga pul topshirish",
        'finance.confirm' => "Karta/bank to'lovlarini tasdiqlash",
        'finance.view' => "Moliyani ko'rish (direktor hisobi)",
        'finance.handover' => "Kassadan topshirilgan pulni qabul qilish",
        'finance.expenses' => "Xarajat va daromad kiritish",
        'payroll.view' => "Ish haqini ko'rish",
        'payroll.manage' => "Ish haqini hisoblash va to'lash",
        'reports.view' => "Hisobotlarni ko'rish",
        'settings.manage' => "Sozlamalarni o'zgartirish",
        'sms.manage' => "SMS sozlamalarini boshqarish",
        'roles.manage' => "Rollarni boshqarish",
        'subscription.manage' => "Obuna va balansni boshqarish",
    ],

    // Ruxsatlar bo'limlar bo'yicha guruhlangan (lavozim sozlash sahifasida)
    'permission_groups' => [
        'Bolalar va guruhlar' => ['kids.view', 'kids.manage', 'groups.view', 'groups.manage', 'clubs.view', 'clubs.manage'],
        'Davomad' => ['attendance.kids', 'attendance.staff'],
        'Xodimlar' => ['employees.view', 'employees.manage', 'payroll.view', 'payroll.manage'],
        'Arizalar' => ['leads.view', 'leads.manage'],
        'Kassa' => ['desk.view', 'finance.payments', 'desk.handover', 'finance.confirm'],
        'Moliya (direktor hisobi)' => ['finance.view', 'finance.handover', 'finance.expenses'],
        'Hisobotlar va sozlamalar' => ['reports.view', 'settings.manage', 'sms.manage', 'roles.manage', 'subscription.manage'],
    ],

    // Har bir yangi bog'chaga yaratiladigan boshlang'ich lavozimlar (direktor o'zgartira, o'chira va yangisini qo'sha oladi)
    'system_roles' => [
        'director' => ['name' => 'Direktor', 'permissions' => ['*']],
        'admin' => ['name' => 'Administrator', 'permissions' => [
            'kids.view', 'kids.manage', 'groups.view', 'groups.manage', 'clubs.view', 'clubs.manage', 'attendance.kids', 'attendance.staff',
            'employees.view', 'employees.manage', 'leads.view', 'leads.manage', 'desk.view', 'finance.payments', 'desk.handover',
            'finance.confirm', 'payroll.view', 'reports.view', 'sms.manage', 'settings.manage',
        ]],
        'accountant' => ['name' => 'Hisobchi', 'permissions' => [
            'kids.view', 'desk.view', 'finance.view', 'finance.payments', 'finance.confirm', 'finance.handover', 'finance.expenses',
            'payroll.view', 'payroll.manage', 'reports.view', 'employees.view',
        ]],
        'cashier' => ['name' => 'Kassir', 'permissions' => ['kids.view', 'desk.view', 'finance.payments', 'desk.handover']],
        'teacher' => ['name' => 'Tarbiyachi', 'permissions' => ['kids.view', 'groups.view', 'clubs.view', 'attendance.kids', 'leads.view']],
        'assistant' => ['name' => 'Yordamchi tarbiyachi', 'permissions' => ['kids.view', 'groups.view', 'attendance.kids']],
        'cook' => ['name' => 'Oshpaz', 'permissions' => []],
        'nurse' => ['name' => 'Hamshira', 'permissions' => ['kids.view']],
        'cleaner' => ['name' => 'Farrosh', 'permissions' => []],
        'staff' => ['name' => 'Boshqa xodim', 'permissions' => []],
    ],

    /* ---------------- Bog'cha sozlamalari reyestri ----------------
     | type: bool | int | string | text | select | multiselect | list | time
     | feature: shu xususiyat yoqiq bo'lsagina sozlama ko'rinadi
     | option_features: select variantlari uchun kerakli xususiyat
     */
    'settings' => [
        'general' => [
            'title' => 'Umumiy',
            'items' => [
                'general.currency' => ['type' => 'string', 'default' => "so'm", 'label' => "Valyuta nomi"],
                'general.working_days' => ['type' => 'multiselect', 'default' => [1, 2, 3, 4, 5], 'label' => "Ish kunlari",
                    'options' => [1 => 'Dushanba', 2 => 'Seshanba', 3 => 'Chorshanba', 4 => 'Payshanba', 5 => 'Juma', 6 => 'Shanba', 7 => 'Yakshanba']],
                'general.birthday_widget' => ['type' => 'bool', 'default' => true, 'label' => "Bosh sahifada tug'ilgan kunlarni ko'rsatish"],
            ],
        ],
        'billing' => [
            'title' => "Bolalar to'lovi",
            'items' => [
                'billing.mode' => ['type' => 'select', 'default' => 'monthly_fixed', 'label' => "Hisoblash usuli",
                    'help' => "Oylik — har oy guruh narxi to'liq yechiladi. Proporsional — oy o'rtasida kelgan bolaga faqat qolgan ish kunlari uchun. Kunlik (davomadga qarab) — guruh narxi oydagi ish kunlariga bo'linadi va faqat «keldi» deb belgilangan kunlar yechiladi; hisob keyingi oyning belgilangan kunida o'tgan oy uchun bajariladi. Masalan: narx 600 000, oyda 24 ish kuni, bola 18 kun kelgan → 450 000 so'm.",
                    'options' => ['monthly_fixed' => "Oylik (har oy to'liq)", 'prorated' => "Proporsional (kirgan kundan)", 'per_day' => "Kunlik (davomadga qarab)"],
                    'option_features' => ['prorated' => 'billing_prorate', 'per_day' => 'billing_per_day']],
                'billing.auto_charge' => ['type' => 'bool', 'default' => true, 'label' => "Oylik to'lovni avtomatik yechish"],
                'billing.charge_day' => ['type' => 'int', 'default' => 1, 'min' => 1, 'max' => 28, 'label' => "Har oyning nechanchi kuni hisoblansin"],
                'billing.sibling_discount' => ['type' => 'int', 'default' => 0, 'min' => 0, 'max' => 100, 'label' => "Aka-uka/opa-singil chegirmasi (%)", 'help' => "Bir ota-onaning 2-bolasidan boshlab qo'llanadi"],
                'billing.debt_warning' => ['type' => 'int', 'default' => 0, 'min' => 0, 'label' => "Qarz ogohlantirish chegarasi (so'm)", 'help' => "0 — o'chirilgan. Qarz shu summadan oshsa, bola qizil belgi bilan ko'rsatiladi"],
            ],
        ],
        'finance' => [
            'title' => 'Moliya',
            'feature' => 'finance',
            'items' => [
                'finance.method_cash' => ['type' => 'bool', 'default' => true, 'label' => "Naqd to'lovni yoqish"],
                'finance.method_card' => ['type' => 'bool', 'default' => true, 'label' => "Karta to'lovini yoqish"],
                'finance.method_bank' => ['type' => 'bool', 'default' => true, 'label' => "Bank o'tkazmasini yoqish"],
                'finance.require_confirmation' => ['type' => 'bool', 'default' => true, 'label' => "Karta/bank to'lovlari tasdiqlanishi kerak",
                    'help' => "Yoqilsa, to'lov 'kutilmoqda' bo'ladi va hisobchi tasdiqlagach bola hisobiga tushadi"],
                'finance.allow_negative_cash' => ['type' => 'bool', 'default' => false, 'label' => "Kassa qoldig'i manfiy bo'lishiga ruxsat"],
            ],
        ],
        'attendance' => [
            'title' => 'Davomad',
            'feature' => 'attendance',
            'items' => [
                'attendance.late_after' => ['type' => 'time', 'default' => '09:00', 'label' => "Xodim kechikkan hisoblanadigan vaqt", 'feature' => 'staff_attendance'],
                'attendance.lock_days' => ['type' => 'int', 'default' => 7, 'min' => 0, 'label' => "Necha kundan keyin davomadni o'zgartirib bo'lmaydi", 'help' => "0 — cheklov yo'q"],
            ],
        ],
        'payroll' => [
            'title' => 'Ish haqi',
            'feature' => 'payroll',
            'items' => [
                'payroll.strategy' => ['type' => 'select', 'default' => 'fixed', 'label' => "Ish haqi hisoblash usuli",
                    'help' => "Belgilangan — har oy bir xil oylik. Davomadga qarab — bir kunlik stavka × ishlagan kunlar. Aralash — belgilangan oylik + xodim biriktirilgan guruhlardagi har bir bola uchun qo'shimcha (KPI). Masalan: oylik 3 000 000 + 15 bola × 50 000 = 3 750 000 so'm. Aralash usul Premium nashrda; xodim kartasida har biriga alohida usul ham tanlash mumkin.",
                    'options' => ['fixed' => "Belgilangan oylik", 'attendance' => "Davomadga qarab", 'hybrid' => "Aralash (asosiy + KPI)"],
                    'option_features' => ['attendance' => 'payroll_attendance', 'hybrid' => 'payroll_hybrid']],
                'payroll.late_penalty' => ['type' => 'int', 'default' => 0, 'min' => 0, 'label' => "Kechikish jarimasi (har bir kechikish uchun, so'm)", 'feature' => 'staff_attendance'],
                'payroll.working_days' => ['type' => 'int', 'default' => 0, 'min' => 0, 'max' => 31, 'label' => "Oydagi ish kunlari soni (0 — kalendardan avtomatik)"],
            ],
        ],
        'leads' => [
            'title' => 'Arizalar',
            'feature' => 'leads',
            'items' => [
                'leads.statuses' => ['type' => 'list', 'default' => ['Yangi', 'Aloqa qilindi', 'Tashrif buyurdi', 'Qabul qilindi', 'Rad etildi'], 'label' => "Ariza bosqichlari (voronka)",
                    'help' => "Har bir bosqichni yangi qatordan yozing. Birinchisi — yangi ariza, oxirgi ikkitasi — muvaffaqiyatli va rad etilgan."],
                'leads.sources' => ['type' => 'list', 'default' => ['Instagram', 'Telegram', "Do'st tavsiyasi", 'Sayt', 'Boshqa'], 'label' => "Ariza manbalari"],
                'leads.public_form' => ['type' => 'bool', 'default' => true, 'label' => "Ochiq ariza formasi yoqilgan"],
            ],
        ],
    ],

    /* ---------------- SMS hodisalari ----------------
     | scope: tenant — bog'cha ota-onaga yuboradi; platform — platforma yuboradi
     | vars: shablonda ishlatiladigan o'zgaruvchilar
     */
    'sms_events' => [
        'payment_received' => [
            'scope' => 'tenant', 'label' => "To'lov qabul qilindi", 'default_on' => true,
            'body' => "{bogcha}: {bola} uchun {summa} so'm to'lov qabul qilindi. Rahmat!",
            'vars' => ['bogcha', 'bola', 'summa'],
        ],
        'debt_reminder' => [
            'scope' => 'tenant', 'label' => "Qarz eslatmasi", 'default_on' => false,
            'body' => "{bogcha}: {bola} uchun {summa} so'm qarzdorlik mavjud. Iltimos, to'lovni amalga oshiring.",
            'vars' => ['bogcha', 'bola', 'summa'],
        ],
        'kid_absent' => [
            'scope' => 'tenant', 'label' => "Bola kelmadi", 'default_on' => false,
            'body' => "{bogcha}: {bola} bugun bog'chaga kelmadi. Sababini bilsak bo'ladimi?",
            'vars' => ['bogcha', 'bola'],
        ],
        'birthday' => [
            'scope' => 'tenant', 'label' => "Tug'ilgan kun tabrigi", 'default_on' => false,
            'body' => "{bogcha} jamoasi {bola}ni tug'ilgan kuni bilan tabriklaydi!",
            'vars' => ['bogcha', 'bola'],
        ],
        'lead_welcome' => [
            'scope' => 'tenant', 'label' => "Yangi ariza qabul qilindi", 'default_on' => false,
            'body' => "{bogcha}: arizangiz qabul qilindi. Tez orada siz bilan bog'lanamiz.",
            'vars' => ['bogcha'],
        ],
        'bulk' => [
            'scope' => 'tenant', 'label' => "Ommaviy xabar", 'default_on' => true,
            'body' => "{bogcha}: {matn}",
            'vars' => ['bogcha', 'matn'],
        ],
        // Platforma xabarlari
        'otp' => [
            'scope' => 'platform', 'label' => "Tasdiqlash kodi",
            'body' => "KinderDesk: tasdiqlash kodingiz {kod}. Uni hech kimga bermang.",
            'vars' => ['kod'],
        ],
        'subscription_expiring' => [
            'scope' => 'platform', 'label' => "Obuna tugashiga 3 kun qoldi",
            'body' => "KinderDesk: {bogcha} obunasi {sana} kuni tugaydi. Uzilishsiz ishlash uchun obunani yangilang.",
            'vars' => ['bogcha', 'sana'],
        ],
        'subscription_expired' => [
            'scope' => 'platform', 'label' => "Obuna tugadi",
            'body' => "KinderDesk: {bogcha} obunasi tugadi. Tizim faqat ko'rish rejimida. Obunani yangilang.",
            'vars' => ['bogcha'],
        ],
        'subscription_renewed' => [
            'scope' => 'platform', 'label' => "Obuna avtomatik yangilandi",
            'body' => "KinderDesk: {bogcha} obunasi balansdan {sana} gacha yangilandi.",
            'vars' => ['bogcha', 'sana'],
        ],
    ],

    // Eskiz shablon holatlarini ichki holatga o'tkazish jadvali.
    // Eskiz hujjatiga qarab kerak bo'lsa shu yerni to'g'rilang.
    'eskiz_status_map' => [
        'approved' => ['service', 'reklama', 'active', 'approved', 'accepted', 'confirmed', 'sent'],
        'rejected' => ['rejected', 'reject', 'cancel', 'canceled', 'cancelled', 'declined', 'blocked'],
        'pending' => ['moderation', 'pending', 'new', 'wait', 'waiting', 'review'],
    ],

    'attendance_statuses' => [
        'present' => 'Keldi',
        'absent' => 'Kelmadi',
        'sick' => 'Kasal',
    ],
    'staff_attendance_statuses' => [
        'present' => 'Keldi',
        'late' => 'Kechikdi',
        'absent' => 'Kelmadi',
        'leave' => "Ta'tilda",
    ],
];
