<?php

namespace App\Services\Finance;

use App\Models\Club;
use App\Models\ClubAttendance;
use App\Models\ClubKid;
use App\Models\Group;
use App\Models\GroupKid;
use App\Models\Kid;
use App\Models\KidAttendance;
use App\Models\Tenant;
use App\Support\Tenancy\TenantContext;
use Illuminate\Support\Carbon;

/**
 * Bolalarga oylik to'lovni hisoblash. Takroriy ishga tushirishdan xavfsiz (charge_key noyob).
 * Usullar: monthly_fixed (har oy to'liq), prorated (kirgan kundan), per_day (davomadga qarab).
 */
class ChargeService
{
    public function __construct(private FinanceService $finance, private TenantContext $context)
    {
    }

    /** Bog'cha uchun joriy davrni hisoblaydi. @return array{charged:int, skipped:int} */
    public function runForTenant(Tenant $tenant, ?Carbon $today = null, bool $force = false): array
    {
        $today ??= today();

        return $this->context->run($tenant, function () use ($tenant, $today, $force) {
            $stats = ['charged' => 0, 'skipped' => 0];
            if (! $force && (! $tenant->setting('billing.auto_charge', true) || $tenant->isReadOnly())) {
                return $stats;
            }
            $mode = $tenant->setting('billing.mode', 'monthly_fixed');
            $chargeDay = (int) $tenant->setting('billing.charge_day', 1);

            if ($mode === 'per_day') {
                // O'tgan oy yakunlangach, davomad bo'yicha
                if ($today->day >= $chargeDay || $force) {
                    $period = $today->copy()->subMonthNoOverflow()->startOfMonth();
                    Kid::where(fn ($q) => $q->where('status', 'active')->orWhere(fn ($w) => $w->where('status', 'archived')->whereDate('archived_on', '>=', $period)))->each(function (Kid $kid) use ($period, $mode, &$stats) {
                        $this->chargeKid($kid, $period, $mode) ? $stats['charged']++ : $stats['skipped']++;
                    });
                }
            } elseif ($today->day >= $chargeDay || $force) {
                $period = $today->copy()->startOfMonth();
                Kid::active()->each(function (Kid $kid) use ($period, $mode, &$stats) {
                    $this->chargeKid($kid, $period, $mode) ? $stats['charged']++ : $stats['skipped']++;
                });
            }

            // To'garaklarning oylik to'lovi (har oyning 1-sanasidan, hisob kunidan qat'i nazar)
            if (feature('clubs') && ($tenant->setting('billing.auto_charge', true) || $force)) {
                ClubKid::with('club', 'kid')->whereNull('ended_on')->get()->each(function (ClubKid $link) use ($today, &$stats) {
                    if ($link->club && $link->club->status === 'active' && ! $link->club->isPerSession() && $link->kid?->status === 'active') {
                        $this->chargeClubMonth($link->kid, $link->club, $today->copy()->startOfMonth()) ? $stats['charged']++ : $stats['skipped']++;
                    }
                });
            }

            return $stats;
        });
    }

    /** Yangi qabul qilingan bola uchun (joriy oy hisob kuni o'tgan bo'lsa). */
    public function chargeOnEnroll(Kid $kid): void
    {
        $t = tenant();
        if (! $t->setting('billing.auto_charge', true) || $t->setting('billing.mode') === 'per_day') {
            return;
        }
        if (today()->day >= (int) $t->setting('billing.charge_day', 1)) {
            $this->chargeKid($kid, today()->startOfMonth(), $t->setting('billing.mode', 'monthly_fixed'));
        }
    }

    /** Bitta bola, bitta davr. Hisoblangan bo'lsa true. */
    public function chargeKid(Kid $kid, Carbon $period, string $mode): bool
    {
        $period = $period->copy()->startOfMonth();
        $end = $period->copy()->endOfMonth();
        $links = GroupKid::with('group')->where('kid_id', $kid->id)
            ->whereHas('group', fn ($q) => $q->where('type', 'main'))
            ->whereDate('started_on', '<=', $end)
            ->where(fn ($q) => $q->whereNull('ended_on')->orWhereDate('ended_on', '>=', $period))
            ->orderBy('started_on')->get();
        if ($links->isEmpty()) {
            return false;
        }

        $gross = 0;
        $desc = '';
        $groupId = $links->last()->group_id;
        $feeOf = fn (Group $g) => $kid->custom_fee ?? $g->monthly_fee;

        if ($mode === 'monthly_fixed') {
            $gross = $feeOf($links->last()->group);
            $desc = $links->last()->group->name.': '.$this->label($period);
        } else {
            $workDays = $this->workingDays($period);
            $total = max(1, count($workDays));
            foreach ($links as $link) {
                $from = $link->started_on->greaterThan($period) ? $link->started_on : $period;
                $to = ($link->ended_on && $link->ended_on->lessThan($end)) ? $link->ended_on : $end;
                $fee = $feeOf($link->group);
                if ($mode === 'prorated') {
                    $days = collect($workDays)->filter(fn ($d) => $d->between($from, $to))->count();
                    $gross += (int) round($fee * $days / $total);
                } else { // per_day
                    $present = KidAttendance::where('kid_id', $kid->id)->where('status', 'present')
                        ->where('group_id', $link->group_id)
                        ->whereBetween('date', [$from->toDateString(), $to->toDateString()])->count();
                    $gross += (int) round($fee * $present / $total);
                }
            }
            $desc = ($mode === 'prorated' ? 'Proporsional hisob' : 'Kunlik hisob').': '.$this->label($period);
        }
        $gross = (int) round($gross);
        if ($gross <= 0) {
            return false;
        }

        $key = $period->format('Y-m').':m';
        if (! $this->finance->charge($kid, $period, -$gross, $key, $groupId, $desc)) {
            return false;
        }

        // Aka-uka chegirmasi: bir ota-onaning 2-bolasidan boshlab
        $pct = (int) tenant()->setting('billing.sibling_discount', 0);
        if ($pct > 0 && $kid->parent_phone) {
            $order = Kid::where('parent_phone', $kid->parent_phone)->where('status', 'active')->orderBy('id')->pluck('id')->values();
            if ($order->search($kid->id) > 0) {
                $this->finance->charge($kid, $period, (int) round($gross * $pct / 100), $period->format('Y-m').':disc', $groupId, "Aka-uka chegirmasi ($pct%)", 'discount');
            }
        }

        return true;
    }

    /* ---------------- Kunlik guruhlar (shanba / kechki) ---------------- */

    /**
     * Shanba va kechki guruh: faqat belgilangan ("keldi") kun uchun bolaning hisobidan yechiladi.
     * Keyin "kelmadi"ga o'zgartirilsa — o'sha kun uchun yechim bekor qilinadi.
     */
    public function syncDaily(Kid $kid, Group $group, Carbon $date, string $status): void
    {
        if (! $group->isDaily() || $group->daily_fee <= 0) {
            return;
        }
        $key = 'd:'.$date->toDateString().':g'.$group->id;
        if ($status === 'present') {
            $label = $group->name.': '.$date->format('d.m.Y');
            $this->finance->charge($kid, $date, -$group->daily_fee, $key, $group->id, $label);
        } else {
            $this->finance->cancelCharge($kid, $key);
        }
    }

    /* ---------------- To'garaklar ---------------- */

    public function chargeClubMonth(Kid $kid, Club $club, Carbon $period): bool
    {
        if ($club->fee <= 0) {
            return false;
        }

        return $this->finance->charge($kid, $period, -$club->fee, $period->format('Y-m').':c'.$club->id, null,
            "To'garak: {$club->name} ({$this->label($period)})", 'charge', $club->id);
    }

    /** To'garak mashg'ulotiga qatnashgan kun uchun (per_session) yechim. */
    public function syncClubSession(Kid $kid, Club $club, Carbon $date, string $status): void
    {
        if (! $club->isPerSession() || $club->fee <= 0) {
            return;
        }
        $key = 'cs:'.$date->toDateString().':c'.$club->id;
        if ($status === 'present') {
            $this->finance->charge($kid, $date, -$club->fee, $key, null, "To'garak: {$club->name} — ".$date->format('d.m.Y'), 'charge', $club->id);
        } else {
            $this->finance->cancelCharge($kid, $key);
        }
    }

    /** @return Carbon[] oydagi ish kunlari */
    public function workingDays(Carbon $period): array
    {
        $workDays = (array) tenant()->setting('general.working_days', [1, 2, 3, 4, 5]);
        $out = [];
        for ($d = $period->copy()->startOfMonth(); $d->lte($period->copy()->endOfMonth()); $d->addDay()) {
            if (in_array($d->dayOfWeekIso, $workDays, true)) {
                $out[] = $d->copy();
            }
        }

        return $out;
    }

    private function label(Carbon $p): string
    {
        return $p->format('m.Y');
    }
}
