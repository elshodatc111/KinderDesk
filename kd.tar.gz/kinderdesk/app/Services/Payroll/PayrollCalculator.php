<?php

namespace App\Services\Payroll;

use App\Models\Employee;
use App\Models\EmployeeAttendance;
use App\Models\GroupKid;
use App\Services\Finance\ChargeService;
use Illuminate\Support\Carbon;

/**
 * Ish haqi hisoblash. Usul bog'cha sozlamasidan (yoki xodimning shaxsiy sozlamasidan) olinadi:
 *  fixed      — belgilangan oylik
 *  attendance — ishlagan kunlarga qarab (kunlik stavka × kelgan kunlar)
 *  hybrid     — asosiy oylik + guruhdagi bolalar soniga qo'shimcha (KPI)
 * Kechikish jarimasi (xodimlar davomadi yoqilgan bo'lsa) barcha usullarga qo'llanadi.
 */
class PayrollCalculator
{
    public function __construct(private ChargeService $charges)
    {
    }

    public function strategyFor(Employee $e): string
    {
        $t = tenant();
        $wanted = $e->salary_type ?: $t->setting('payroll.strategy', 'fixed');
        if ($wanted === 'attendance' && ! $t->hasFeature('payroll_attendance')) {
            return 'fixed';
        }
        if ($wanted === 'hybrid' && ! $t->hasFeature('payroll_hybrid')) {
            return 'fixed';
        }

        return $wanted;
    }

    /** @return array{strategy:string, base_amount:int, worked_days:int, working_days:int, late_count:int, kids_count:int, kpi_amount:int, penalty:int, total:int} */
    public function calculate(Employee $e, Carbon $period): array
    {
        $t = tenant();
        $period = $period->copy()->startOfMonth();
        $end = $period->copy()->endOfMonth();
        $strategy = $this->strategyFor($e);

        $workingDays = (int) $t->setting('payroll.working_days', 0) ?: count($this->charges->workingDays($period));
        $workingDays = max(1, $workingDays);

        $worked = 0;
        $late = 0;
        if ($t->hasFeature('staff_attendance')) {
            $rows = EmployeeAttendance::where('employee_id', $e->id)->whereBetween('date', [$period->toDateString(), $end->toDateString()])->pluck('status');
            $worked = $rows->filter(fn ($s) => in_array($s, ['present', 'late'], true))->count();
            $late = $rows->filter(fn ($s) => $s === 'late')->count();
        }

        $base = 0;
        $kids = 0;
        $kpi = 0;
        switch ($strategy) {
            case 'attendance':
                $daily = $e->daily_rate ?: (int) round($e->base_salary / $workingDays);
                $base = $daily * $worked;
                break;
            case 'hybrid':
                $base = $e->base_salary;
                $groupIds = $e->groupLinks()->where(fn ($q) => $q->whereNull('ended_on')->orWhereDate('ended_on', '>=', $period))->whereDate('started_on', '<=', $end)->pluck('group_id');
                $kids = $groupIds->isEmpty() ? 0 : GroupKid::whereIn('group_id', $groupIds)->whereDate('started_on', '<=', $end)
                    ->where(fn ($q) => $q->whereNull('ended_on')->orWhereDate('ended_on', '>=', $end))->distinct('kid_id')->count('kid_id');
                $kpi = $kids * $e->kpi_per_kid;
                break;
            default:
                $base = $e->base_salary;
        }

        $penalty = $t->hasFeature('staff_attendance') ? $late * (int) $t->setting('payroll.late_penalty', 0) : 0;
        $total = max(0, $base + $kpi - $penalty);

        return ['strategy' => $strategy, 'base_amount' => (int) $base, 'worked_days' => $worked, 'working_days' => $workingDays,
            'late_count' => $late, 'kids_count' => $kids, 'kpi_amount' => (int) $kpi, 'penalty' => (int) $penalty, 'total' => (int) $total];
    }
}
