<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

/** Platforma darajasidagi sozlamalar (karta raqami, aloqa va h.k.). */
class PlatformSetting extends Model
{
    protected $fillable = ['key', 'value'];

    public const DEFAULTS = [
        'payment.card_number' => '',
        'payment.card_holder' => '',
        'payment.card_bank' => '',
        'payment.min_topup' => '10000',
        'payment.note' => "To'lovdan keyin chek rasmini 'Obuna' bo'limidan yuboring.",
        'support.phone' => '',
        'support.telegram' => '',
    ];

    public static function get(string $key, ?string $default = null): ?string
    {
        $all = Cache::remember('platform_settings', 300, fn () => static::query()->pluck('value', 'key')->all());

        return $all[$key] ?? static::DEFAULTS[$key] ?? $default;
    }

    public static function put(string $key, ?string $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value]);
        Cache::forget('platform_settings');
    }
}
