<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PlatformSetting;
use App\Models\SmsLog;
use App\Models\SmsTemplate;
use App\Services\Billing\TopupService;
use App\Services\Sms\SmsManager;
use App\Services\Sms\SmsService;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index(TopupService $topups)
    {
        // Platforma shablonlari: yo'q bo'lsa standart matn bilan qoralama yaratamiz
        foreach (config('kinderdesk.sms_events') as $key => $def) {
            if ($def['scope'] === 'platform') {
                SmsTemplate::firstOrCreate(['tenant_id' => null, 'event_key' => $key], ['name' => $def['label'], 'body' => $def['body'], 'status' => 'draft']);
            }
        }

        return view('admin.settings', [
            'values' => collect(array_keys(PlatformSetting::DEFAULTS))->mapWithKeys(fn ($k) => [$k => PlatformSetting::get($k)])->all(),
            'templates' => SmsTemplate::whereNull('tenant_id')->orderBy('id')->get(),
            'events' => config('kinderdesk.sms_events'),
            'smsDriver' => config('services.sms.driver'),
            'paymeEnabled' => $topups->paymeEnabled(),
            'paymeTest' => config('services.payme.test_mode'),
            'logs' => SmsLog::whereNull('tenant_id')->latest('id')->limit(10)->get(),
            'eskizConfigured' => filled(config('services.eskiz.email')) && filled(config('services.eskiz.password')),
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'payment_card_number' => 'nullable|string|max:30',
            'payment_card_holder' => 'nullable|string|max:80',
            'payment_card_bank' => 'nullable|string|max:60',
            'payment_min_topup' => 'required|integer|min:1000',
            'payment_note' => 'nullable|string|max:300',
            'support_phone' => 'nullable|string|max:30',
            'support_telegram' => 'nullable|string|max:60',
        ]);
        foreach ($data as $k => $v) {
            // payment_card_number -> payment.card_number
            PlatformSetting::put(preg_replace('/^(payment|support)_/', '$1.', $k), $v);
        }

        return back()->with('success', 'Sozlamalar saqlandi');
    }

    public function templateUpdate(Request $request, SmsTemplate $template)
    {
        abort_if($template->tenant_id !== null, 404);
        $data = $request->validate(['body' => 'required|string|max:480']);
        $template->update(['body' => $data['body'], 'status' => 'draft', 'rejection_reason' => null, 'eskiz_template_id' => null]);

        return back()->with('success', 'Matn saqlandi. Eskizga tasdiqlash uchun yuboring.');
    }

    public function templateSubmit(SmsTemplate $template, SmsService $sms)
    {
        abort_if($template->tenant_id !== null, 404);
        try {
            $sms->submitTemplate($template, null);
        } catch (\Throwable $e) {
            return back()->with('error', 'Yuborilmadi: '.$e->getMessage());
        }

        return back()->with('success', 'Eskiz moderatsiyasiga yuborildi');
    }

    public function templatesSync(SmsService $sms)
    {
        try {
            $n = $sms->syncTemplates(null);
        } catch (\Throwable $e) {
            return back()->with('error', 'Tekshirib bo\'lmadi: '.$e->getMessage());
        }

        return back()->with('success', __("Holatlar yangilandi (:n ta shablon)", ['n' => $n]));
    }

    public function templateTest(Request $request, SmsTemplate $template, SmsManager $manager, SmsService $sms)
    {
        abort_if($template->tenant_id !== null, 404);
        $data = $request->validate(['phone' => 'required|string']);
        $phone = normalize_phone($data['phone']);
        if (! $phone) {
            return back()->with('error', "Telefon raqam noto'g'ri");
        }
        $message = $sms->render($template->body, ['kod' => '123456', 'bogcha' => 'Sinov bog\'chasi', 'sana' => now()->format('d.m.Y')]);
        $result = $manager->platform()->send($phone, $message);
        SmsLog::create(['tenant_id' => null, 'to' => $phone, 'event_key' => 'test', 'template_id' => $template->id, 'message' => $message,
            'status' => $result->ok ? 'sent' : 'failed', 'provider_id' => $result->providerId, 'error' => $result->error]);

        return back()->with($result->ok ? 'success' : 'error', $result->ok ? 'Sinov SMS yuborildi' : 'Yuborilmadi: '.$result->error);
    }

    public function eskizCheck(SmsManager $manager)
    {
        if (config('services.sms.driver') !== 'eskiz') {
            return back()->with('error', "SMS_DRIVER=eskiz qilib .env faylida yoqilmagan. Hozir sinov (log) rejimi.");
        }
        try {
            $balance = $manager->platformClient()->balance();
        } catch (\Throwable $e) {
            return back()->with('error', 'Eskiz bilan ulanib bo\'lmadi: '.$e->getMessage());
        }

        return back()->with('success', "Eskiz ulangan. Balans: ".number_format((int) $balance, 0, '', ' ')." SMS");
    }
}
