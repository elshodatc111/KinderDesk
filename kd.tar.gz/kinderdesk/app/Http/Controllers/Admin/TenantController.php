<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Edition;
use App\Models\Tenant;
use App\Models\TenantFeatureOverride;
use App\Services\Billing\SubscriptionService;
use App\Services\Billing\WalletService;
use App\Services\NotificationService;
use App\Services\Tenancy\TenantDeleter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class TenantController extends Controller
{
    public function index(Request $request)
    {
        $q = Tenant::with('edition')->latest('id');
        if ($s = trim((string) $request->query('q'))) {
            $digits = preg_replace('/\D/', '', $s);
            $q->where(fn ($w) => $w->where('name', 'like', "%$s%")->orWhere('email', 'like', "%$s%")
                ->when($digits, fn ($x) => $x->orWhere('phone', 'like', "%$digits%")->orWhere('tax_id', 'like', "%$digits%")));
        }
        if ($e = $request->query('edition')) {
            $q->whereHas('edition', fn ($x) => $x->where('key', $e));
        }
        $all = $q->get();
        if ($st = $request->query('state')) {
            $all = $all->filter(fn ($t) => $t->accessState() === $st || ($st === 'delete' && $t->accessState() === 'read_only' && $t->daysSinceExpiry() >= config('kinderdesk.delete_after_days')))->values();
        }

        return view('admin.tenants.index', ['tenants' => $all, 'editions' => Edition::orderBy('sort')->get()]);
    }

    public function show(Tenant $tenant)
    {
        $tenant->load('edition', 'owner');

        return view('admin.tenants.show', [
            'tenant' => $tenant,
            'editions' => Edition::orderBy('sort')->get(),
            'features' => config('kinderdesk.features'),
            'overrides' => $tenant->featureOverrides()->pluck('enabled', 'feature_key')->all(),
            'subscriptions' => $tenant->subscriptions()->latest('id')->limit(8)->get(),
            'transactions' => $tenant->walletTransactions()->latest('id')->limit(10)->get(),
            'counts' => [
                'users' => $tenant->users()->count(),
                'kids' => \DB::table('kids')->where('tenant_id', $tenant->id)->count(),
                'employees' => \DB::table('employees')->where('tenant_id', $tenant->id)->count(),
                'groups' => \DB::table('groups')->where('tenant_id', $tenant->id)->count(),
            ],
        ]);
    }

    public function grant(Request $request, Tenant $tenant, SubscriptionService $subs)
    {
        $data = $request->validate(['edition_id' => 'required|exists:editions,id', 'months' => 'required|integer|min:1|max:36']);
        $subs->grant($tenant, Edition::findOrFail($data['edition_id']), (int) $data['months'], $request->user()->id);

        return back()->with('success', __(':months oy bepul muddat berildi', ['months' => $data['months']]));
    }

    public function edition(Request $request, Tenant $tenant)
    {
        $data = $request->validate(['edition_id' => 'required|exists:editions,id']);
        $tenant->update(['edition_id' => $data['edition_id']]);
        $tenant->forgetCaches();
        AuditLog::record('tenant.edition_changed', $tenant, ['edition' => $data['edition_id']], $tenant->id);

        return back()->with('success', 'Nashr o\'zgartirildi');
    }

    public function features(Request $request, Tenant $tenant)
    {
        $state = $request->input('f', []); // feature => default|on|off
        foreach (config('kinderdesk.features') as $key => $def) {
            if (! empty($def['core'])) {
                continue;
            }
            $v = $state[$key] ?? 'default';
            if ($v === 'default') {
                TenantFeatureOverride::where('tenant_id', $tenant->id)->where('feature_key', $key)->delete();
            } else {
                TenantFeatureOverride::updateOrCreate(['tenant_id' => $tenant->id, 'feature_key' => $key], ['enabled' => $v === 'on']);
            }
        }
        $tenant->forgetCaches();
        AuditLog::record('tenant.features_changed', $tenant, [], $tenant->id);

        return back()->with('success', 'Imkoniyatlar saqlandi');
    }

    public function suspend(Request $request, Tenant $tenant)
    {
        $suspend = $tenant->status !== 'suspended';
        $tenant->update(['status' => $suspend ? 'suspended' : 'active']);
        AuditLog::record($suspend ? 'tenant.suspended' : 'tenant.unsuspended', $tenant, [], $tenant->id);

        return back()->with('success', $suspend ? 'Bog\'cha bloklandi' : 'Blok olib tashlandi');
    }

    public function wallet(Request $request, Tenant $tenant, WalletService $wallet)
    {
        $data = $request->validate(['amount' => 'required|integer|not_in:0', 'note' => 'required|string|max:200']);
        try {
            $amount = (int) $data['amount'];
            $amount > 0
                ? $wallet->credit($tenant, $amount, 'adjustment', $data['note'], null, $request->user()->id)
                : $wallet->debit($tenant, abs($amount), 'adjustment', $data['note'], null, $request->user()->id);
        } catch (\Throwable $e) {
            return back()->with('error', 'Bajarilmadi: '.$e->getMessage());
        }
        AuditLog::record('tenant.wallet_adjusted', $tenant, ['amount' => $data['amount'], 'note' => $data['note']], $tenant->id);

        return back()->with('success', 'Balans yangilandi');
    }

    public function message(Request $request, Tenant $tenant, NotificationService $notify)
    {
        $data = $request->validate(['title' => 'required|string|max:120', 'body' => 'nullable|string|max:400']);
        $notify->toOwner($tenant, $data['title'], $data['body'] ?? '', route('app.dashboard'), 'info', 'bell');

        return back()->with('success', 'Xabar direktorga yuborildi');
    }

    public function impersonate(Request $request, Tenant $tenant)
    {
        abort_unless($tenant->owner, 404);
        AuditLog::record('tenant.impersonated', $tenant, [], $tenant->id);
        $adminId = $request->user()->id;
        Auth::login($tenant->owner);
        $request->session()->regenerate();
        $request->session()->put('impersonator_id', $adminId);

        return redirect()->route('app.dashboard');
    }

    public function destroy(Request $request, Tenant $tenant, TenantDeleter $deleter)
    {
        $data = $request->validate([
            'confirm_name' => 'required|string',
            'password' => 'required|string',
            'reason' => 'nullable|string|max:300',
        ]);
        if (trim($data['confirm_name']) !== $tenant->name) {
            return back()->withErrors(['confirm_name' => "Bog'cha nomi mos kelmadi"]);
        }
        if (! Hash::check($data['password'], $request->user()->password)) {
            return back()->withErrors(['password' => "Parol noto'g'ri"]);
        }
        $deleter->delete($tenant, $request->user(), $data['reason'] ?? null);

        return redirect()->route('admin.tenants.index')->with('success', __('«:tenant» butunlay o\'chirildi', ['tenant' => $tenant->name]));
    }
}
