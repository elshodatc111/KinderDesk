<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Payslip;
use App\Services\Finance\FinanceService;
use App\Services\Payroll\PayrollCalculator;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class PayrollController extends Controller
{
    public function index(Request $request, PayrollCalculator $calc, FinanceService $finance)
    {
        $period = Carbon::parse(($request->query('month') ?: today()->format('Y-m')).'-01');
        $slips = Payslip::with('employee')->whereDate('period', $period)->get()->keyBy('employee_id');
        $employees = Employee::active()->orderBy('full_name')->get();

        $rows = $employees->map(function ($e) use ($slips, $calc, $period) {
            $slip = $slips[$e->id] ?? null;

            return ['employee' => $e, 'slip' => $slip, 'preview' => $slip ? null : $calc->calculate($e, $period)];
        });

        return view('app.payroll.index', [
            'period' => $period, 'rows' => $rows,
            'totalDue' => $slips->sum(fn ($s) => $s->total - $s->paid),
            'accounts' => $finance->enabledAccounts(), 'balances' => $finance->balances(),
            'strategy' => tenant()->setting('payroll.strategy', 'fixed'),
        ]);
    }

    /** Oy uchun barcha xodimlarga hisob-kitob varaqalarini yaratadi (mavjudlari o'zgarmaydi). */
    public function generate(Request $request, PayrollCalculator $calc)
    {
        $period = Carbon::parse(($request->input('month') ?: today()->format('Y-m')).'-01');
        $n = 0;
        foreach (Employee::active()->get() as $e) {
            if (Payslip::where('employee_id', $e->id)->whereDate('period', $period)->exists()) {
                continue;
            }
            $c = $calc->calculate($e, $period);
            if ($c['total'] <= 0 && $c['base_amount'] <= 0) {
                continue;
            }
            Payslip::create($c + ['tenant_id' => tenant()->id, 'employee_id' => $e->id, 'period' => $period->toDateString(), 'bonus' => 0, 'paid' => 0, 'status' => 'approved', 'created_by' => $request->user()->id]);
            $n++;
        }

        return back()->with('success', __(":n ta xodim uchun ish haqi hisoblandi", ['n' => $n]));
    }

    public function recalc(Payslip $payslip, PayrollCalculator $calc)
    {
        if ($payslip->paid > 0) {
            return back()->with('error', "To'lov boshlangan varaqani qayta hisoblab bo'lmaydi");
        }
        $c = $calc->calculate($payslip->employee, $payslip->period);
        $payslip->update($c + ['total' => max(0, $c['total'] + $payslip->bonus)]);

        return back()->with('success', 'Qayta hisoblandi');
    }

    public function adjust(Request $request, Payslip $payslip)
    {
        $data = $request->validate(['bonus' => 'nullable|integer|min:0', 'penalty' => 'nullable|integer|min:0', 'note' => 'nullable|string|max:200']);
        $bonus = (int) ($data['bonus'] ?? 0);
        $penalty = (int) ($data['penalty'] ?? 0);
        $total = max(0, $payslip->base_amount + $payslip->kpi_amount + $bonus - $penalty);
        if ($total < $payslip->paid) {
            return back()->with('error', "Yangi summa allaqachon to'langan summadan kam bo'lishi mumkin emas");
        }
        $payslip->update(['bonus' => $bonus, 'penalty' => $penalty, 'total' => $total, 'note' => $data['note'] ?? null, 'status' => $payslip->paid >= $total && $total > 0 ? 'paid' : 'approved']);

        return back()->with('success', 'Saqlandi');
    }

    public function pay(Request $request, Payslip $payslip, FinanceService $finance)
    {
        $data = $request->validate(['amount' => 'required|string', 'account' => 'required|in:cash,card,bank']);
        $amount = (int) preg_replace('/\D/', '', $data['amount']);
        if ($amount <= 0 || $amount > $payslip->remaining()) {
            return back()->with('error', "Summa noto'g'ri. Qolgan summa: ".money($payslip->remaining())." so'm");
        }
        try {
            DB::transaction(function () use ($finance, $payslip, $amount, $data, $request) {
                $locked = Payslip::lockForUpdate()->findOrFail($payslip->id);
                if ($amount > $locked->remaining()) {
                    throw new \DomainException("Qolgan summadan ko'p kiritildi");
                }
                $finance->record('salary', $data['account'], $amount, 'Ish haqi', $locked->employee->full_name.' — '.$locked->period->format('m.Y'), $request->user(), null, $locked->employee_id, $locked->id);
                $paid = $locked->paid + $amount;
                $locked->update(['paid' => $paid, 'status' => $paid >= $locked->total ? 'paid' : 'approved']);
            });
        } catch (\DomainException $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', "To'landi: ".money($amount)." so'm");
    }

    public function destroy(Payslip $payslip)
    {
        if ($payslip->paid > 0) {
            return back()->with('error', "To'lov boshlangan varaqani o'chirib bo'lmaydi");
        }
        $payslip->delete();

        return back()->with('success', "Varaqa o'chirildi");
    }
}
