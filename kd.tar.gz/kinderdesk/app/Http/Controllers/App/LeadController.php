<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\Lead;
use Illuminate\Http\Request;

class LeadController extends Controller
{
    private function statuses(): array
    {
        return array_values((array) tenant()->setting('leads.statuses'));
    }

    public function index(Request $request)
    {
        $type = $request->query('type', 'kid') === 'employee' ? 'employee' : 'kid';
        $statuses = $this->statuses();
        $leads = Lead::where('type', $type)->latest('id')->get()->groupBy('status');

        return view('app.leads.index', [
            'type' => $type, 'statuses' => $statuses, 'leads' => $leads,
            'sources' => (array) tenant()->setting('leads.sources'),
            'formUrl' => url('/k/'.tenant()->public_key),
            'formEnabled' => (bool) tenant()->setting('leads.public_form', true),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type' => 'required|in:kid,employee', 'name' => 'required|string|max:150', 'phone' => 'required|string',
            'source' => 'nullable|string|max:60', 'note' => 'nullable|string|max:500',
        ]);
        $phone = normalize_phone($data['phone']);
        if (! $phone) {
            return back()->withInput()->with('error', "Telefon raqam noto'g'ri");
        }
        Lead::create($data + ['tenant_id' => tenant()->id, 'phone' => $phone, 'status' => $this->statuses()[0], 'result' => 'open']);

        return redirect()->route('app.leads.index', ['type' => $data['type']])->with('success', "Ariza qo'shildi");
    }

    public function move(Request $request, Lead $lead)
    {
        $statuses = $this->statuses();
        $data = $request->validate(['status' => 'required|string', 'lost_reason' => 'nullable|string|max:200']);
        abort_unless(in_array($data['status'], $statuses, true), 422);
        $count = count($statuses);
        $result = 'open';
        if ($count >= 3) {
            if ($data['status'] === $statuses[$count - 2]) {
                $result = 'won';
            } elseif ($data['status'] === $statuses[$count - 1]) {
                $result = 'lost';
            }
        }
        $lead->update(['status' => $data['status'], 'result' => $result, 'lost_reason' => $result === 'lost' ? ($data['lost_reason'] ?? null) : null]);

        return $request->expectsJson() ? response()->json(['ok' => true, 'result' => $result]) : back()->with('success', 'Holat yangilandi');
    }

    public function update(Request $request, Lead $lead)
    {
        $data = $request->validate(['note' => 'nullable|string|max:500', 'name' => 'required|string|max:150']);
        $lead->update($data);

        return back()->with('success', 'Saqlandi');
    }

    public function destroy(Lead $lead)
    {
        $lead->delete();

        return back()->with('success', "Ariza o'chirildi");
    }
}
