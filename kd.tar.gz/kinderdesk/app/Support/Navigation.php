<?php

namespace App\Support;

use App\Models\User;

/** Yon menyu: xususiyat (feature) va ruxsat (permission) bo'yicha filtrlanadi. */
class Navigation
{
    /** @return array<int, array{group:string, items:array}> */
    public static function tenant(User $user): array
    {
        $all = [
            ['group' => '', 'items' => [
                ['label' => 'Bosh sahifa', 'route' => 'app.dashboard', 'match' => 'app.dashboard', 'icon' => 'home', 'color' => 'teal'],
            ]],
            ['group' => 'Bolalar', 'items' => [
                ['label' => 'Bolalar', 'route' => 'app.kids.index', 'match' => 'app.kids.*', 'icon' => 'kids', 'color' => 'berry', 'feature' => 'kids', 'can' => 'kids.view'],
                ['label' => 'Guruhlar', 'route' => 'app.groups.index', 'match' => 'app.groups.*', 'icon' => 'groups', 'color' => 'sky', 'feature' => 'groups', 'can' => 'groups.view'],
                ['label' => "To'garaklar", 'route' => 'app.clubs.index', 'match' => 'app.clubs.*', 'icon' => 'sparkles', 'color' => 'grape', 'feature' => 'clubs', 'can' => 'clubs.view'],
                ['label' => 'Davomad', 'route' => 'app.attendance.index', 'match' => 'app.attendance.*', 'icon' => 'attendance', 'color' => 'leaf', 'feature' => 'attendance', 'can' => 'attendance.kids'],
                ['label' => 'Arizalar', 'route' => 'app.leads.index', 'match' => 'app.leads.*', 'icon' => 'inbox', 'color' => 'sun', 'feature' => 'leads', 'can' => 'leads.view'],
            ]],
            ['group' => 'Xodimlar', 'items' => [
                ['label' => 'Xodimlar', 'route' => 'app.employees.index', 'match' => 'app.employees.*', 'icon' => 'employees', 'color' => 'grape', 'feature' => 'employees', 'can' => 'employees.view'],
                ['label' => 'Xodimlar davomadi', 'route' => 'app.staff-attendance.index', 'match' => 'app.staff-attendance.*', 'icon' => 'staff-attendance', 'color' => 'leaf', 'feature' => 'staff_attendance', 'can' => 'attendance.staff'],
                ['label' => 'Ish haqi', 'route' => 'app.payroll.index', 'match' => 'app.payroll.*', 'icon' => 'cash', 'color' => 'marigold', 'feature' => 'payroll', 'can' => 'payroll.view'],
            ]],
            ['group' => 'Moliya va tahlil', 'items' => [
                ['label' => 'Kassa', 'route' => 'app.desk.index', 'match' => 'app.desk.*', 'icon' => 'cash', 'color' => 'leaf', 'feature' => 'desk', 'can' => 'desk.view'],
                ['label' => 'Moliya', 'route' => 'app.finance.index', 'match' => 'app.finance.*', 'icon' => 'wallet', 'color' => 'marigold', 'feature' => 'finance', 'can' => 'finance.view'],
                ['label' => 'Hisobotlar', 'route' => 'app.reports.index', 'match' => 'app.reports.*', 'icon' => 'report', 'color' => 'grape', 'feature' => 'reports', 'can' => 'reports.view'],
            ]],
            ['group' => 'Tizim', 'items' => [
                ['label' => 'SMS xabarlar', 'route' => 'app.sms.index', 'match' => 'app.sms.*', 'icon' => 'sms', 'color' => 'teal', 'feature' => 'sms', 'can' => 'sms.manage'],
                ['label' => 'Sozlamalar', 'route' => 'app.settings.index', 'match' => 'app.settings.*', 'icon' => 'settings', 'color' => 'sky', 'can' => 'settings.manage'],
                ['label' => "Yo'riqnoma", 'route' => 'app.guide', 'match' => 'app.guide', 'icon' => 'info', 'color' => 'teal'],
                ['label' => 'Obuna va balans', 'route' => 'app.subscription.index', 'match' => 'app.subscription.*', 'icon' => 'sparkles', 'color' => 'sun', 'can' => 'subscription.manage'],
            ]],
        ];

        $out = [];
        foreach ($all as $group) {
            $items = array_values(array_filter($group['items'], function ($i) use ($user) {
                if (! \Illuminate\Support\Facades\Route::has($i['route'])) {
                    return false;
                }
                if (isset($i['feature']) && ! feature($i['feature'])) {
                    return false;
                }
                if (isset($i['can']) && ! $user->can($i['can'])) {
                    return false;
                }

                return true;
            }));
            if ($items) {
                $out[] = ['group' => $group['group'], 'items' => $items];
            }
        }

        return $out;
    }

    /** Blok ranglari (--block-bg / --block-fg) */
    public static function colors(string $name): string
    {
        return match ($name) {
            'berry' => '--block-bg:var(--color-berry-100);--block-fg:var(--color-berry-700)',
            'sky' => '--block-bg:var(--color-sky-100);--block-fg:var(--color-sky-700)',
            'leaf' => '--block-bg:var(--color-leaf-100);--block-fg:var(--color-leaf-700)',
            'sun' => '--block-bg:var(--color-sun-100);--block-fg:var(--color-sun-700)',
            'grape' => '--block-bg:var(--color-grape-100);--block-fg:var(--color-grape-700)',
            'marigold' => '--block-bg:var(--color-marigold-100);--block-fg:var(--color-marigold-700)',
            default => '--block-bg:var(--color-teal-100);--block-fg:var(--color-teal-700)',
        };
    }
}
