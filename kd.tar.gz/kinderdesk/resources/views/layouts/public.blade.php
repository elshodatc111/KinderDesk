<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>@include('partials.head')@stack('head')</head>
<body class="bg-cloud" x-data="{ menu: false }">
<header class="sticky top-0 z-40 bg-cloud/90 backdrop-blur border-b border-line">
    <div class="max-w-6xl mx-auto px-4 h-16 flex items-center gap-4">
        <a href="{{ route('home') }}" aria-label="KinderDesk"><x-logo size="sm" /></a>
        <nav class="hidden md:flex items-center gap-6 ml-8 font-semibold text-sm">
            <a href="{{ route('home') }}#imkoniyatlar" class="hover:text-teal-700">Imkoniyatlar</a>
            <a href="{{ route('home') }}#nashrlar" class="hover:text-teal-700">Nashrlar</a>
            <a href="{{ route('home') }}#narxlar" class="hover:text-teal-700">Narxlar</a>
            <a href="{{ route('home') }}#savollar" class="hover:text-teal-700">Savollar</a>
        </nav>
        <div class="ml-auto flex items-center gap-2">
            @include('partials.lang-switch')
            @auth
                <a href="{{ auth()->user()->is_super_admin ? route('admin.dashboard') : route('app.dashboard') }}" class="btn btn-sm btn-primary">Kabinetga o'tish</a>
            @else
                <a href="{{ route('login') }}" class="btn btn-sm hidden sm:inline-flex">Kirish</a>
                <a href="{{ route('register') }}" class="btn btn-sm btn-accent">14 kun bepul</a>
            @endauth
        </div>
    </div>
</header>
<main>@yield('content')</main>
<footer class="mt-20 bg-ink text-white/80">
    <div class="max-w-6xl mx-auto px-4 py-10 grid gap-8 md:grid-cols-3">
        <div><x-logo size="sm" class="[&_*]:!text-white" /><p class="mt-3 text-sm font-semibold text-white/60">Xususiy bog'chalar uchun yagona boshqaruv platformasi.</p></div>
        <div class="text-sm font-medium space-y-2">
            <a class="block hover:text-white" href="{{ route('legal', 'oferta') }}">Ommaviy oferta</a>
            <a class="block hover:text-white" href="{{ route('legal', 'privacy') }}">Maxfiylik siyosati</a>
            <a class="block hover:text-white" href="{{ route('legal', 'terms') }}">Foydalanish shartlari</a>
        </div>
        <div class="text-sm font-medium space-y-2">
            @if($p = \App\Models\PlatformSetting::get('support.phone'))<p>Tel: {{ $p }}</p>@endif
            @if($t = \App\Models\PlatformSetting::get('support.telegram'))<p>Telegram: {{ $t }}</p>@endif
        </div>
    </div>
    <p class="text-center text-xs font-medium text-white/40 pb-6">© {{ date('Y') }} KinderDesk</p>
</footer>
@include('partials.flash')
@stack('scripts')
</body>
</html>
