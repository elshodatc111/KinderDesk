@extends('layouts.app')
@section('title', 'Ish haqi')
@section('content')
@php $accLabels = \App\Models\FinanceTransaction::accountLabels(); $sLabels = ['fixed'=>'Belgilangan oylik','attendance'=>'Davomadga qarab','hybrid'=>'Aralash (asosiy + KPI)']; @endphp
<div x-data="{ pay: null }" @keydown.escape.window="pay = null">
<div class="flex flex-wrap items-end justify-between gap-4 mb-5">
    <form method="get"><label class="label">Oy</label><input type="month" name="month" value="{{ $period->format('Y-m') }}" class="input !w-48" onchange="this.form.submit()"></form>
    <div class="flex items-center gap-3"><span class="badge badge-sky">Usul: {{ $sLabels[$strategy] }}</span>
        @can('payroll.manage')<form method="post" action="{{ route('app.payroll.generate') }}">@csrf<input type="hidden" name="month" value="{{ $period->format('Y-m') }}"><button class="btn btn-accent">Oy uchun hisoblash</button></form>@endcan</div>
</div>
@if($totalDue > 0)<div class="banner banner-warn mb-4"><x-icon name="wallet" /><p>To'lanishi kerak: <b>{{ money($totalDue) }} so'm</b></p></div>@endif
<div class="card table-wrap"><div class="table-scroll"><table class="table">
    <thead><tr><th>Xodim</th><th>Asos</th><th>Kun / KPI</th><th>Bonus / jarima</th><th class="text-right">Jami</th><th class="text-right">To'langan</th><th></th></tr></thead><tbody>
@forelse ($rows as $r) @php $e = $r['employee']; $s = $r['slip']; $p = $r['preview']; @endphp
    <tr>
        <td><a href="{{ route('app.employees.show', $e) }}" class="font-semibold hover:underline">{{ $e->full_name }}</a><span class="block text-xs font-semibold text-ink-soft">{{ $e->positionLabel() }}</span></td>
        @if ($s)
            <td>{{ money($s->base_amount) }}</td>
            <td class="text-sm font-semibold text-ink-soft">@if($s->strategy==='attendance'){{ $s->worked_days }}/{{ $s->working_days }} kun @elseif($s->strategy==='hybrid'){{ $s->kids_count }} bola → {{ money($s->kpi_amount) }}@else —@endif @if($s->late_count)<span class="block">Kechikish: {{ $s->late_count }}</span>@endif</td>
            <td>@can('payroll.manage')
                <form method="post" action="{{ route('app.payroll.adjust', $s) }}" class="flex items-center gap-1">@csrf @method('put')
                    <input name="bonus" type="number" min="0" value="{{ $s->bonus }}" class="input !w-24 !py-1" title="Bonus"><input name="penalty" type="number" min="0" value="{{ $s->penalty }}" class="input !w-24 !py-1" title="Jarima"><button class="btn btn-sm">OK</button></form>
                @else +{{ money($s->bonus) }} / −{{ money($s->penalty) }} @endcan</td>
            <td class="text-right font-semibold">{{ money($s->total) }}</td>
            <td class="text-right font-semibold {{ $s->status==='paid' ? 'text-leaf-700' : '' }}">{{ money($s->paid) }}</td>
            <td class="whitespace-nowrap">@can('payroll.manage')
                @if($s->remaining() > 0)<button class="btn btn-sm btn-primary" @click="pay = {{ $s->id }}; $nextTick(() => $refs['amt{{ $s->id }}'] && ($refs['amt{{ $s->id }}'].value = '{{ $s->remaining() }}'))">To'lash</button>@else<span class="badge badge-leaf">To'langan</span>@endif
                @if($s->paid == 0)<form method="post" action="{{ route('app.payroll.recalc', $s) }}" class="inline">@csrf<button class="btn-quiet" title="Qayta hisoblash"><x-icon name="refresh" class="size-4" /></button></form>
                <form method="post" action="{{ route('app.payroll.destroy', $s) }}" class="inline" onsubmit="return confirm(@js(__('Varaqa o\'chiriladi')))">@csrf @method('delete')<button class="btn-quiet !text-danger"><x-icon name="x" class="size-4" /></button></form>@endif
            @endcan</td>
        @else
            <td class="text-ink-mute">{{ money($p['base_amount']) }}</td>
            <td class="text-sm font-semibold text-ink-mute">@if($p['strategy']==='attendance'){{ $p['worked_days'] }}/{{ $p['working_days'] }} kun @elseif($p['strategy']==='hybrid'){{ $p['kids_count'] }} bola → {{ money($p['kpi_amount']) }}@else —@endif</td>
            <td class="text-ink-mute">—</td><td class="text-right text-ink-mute font-medium">{{ money($p['total']) }} <span class="block text-xs">(taxminiy)</span></td><td></td><td></td>
        @endif
    </tr>
@empty<tr><td colspan="7"><div class="empty">Faol xodim yo'q</div></td></tr>@endforelse
</tbody></table></div></div>

@can('payroll.manage')
@foreach ($rows as $r) @if($r['slip'])
<div x-show="pay === {{ $r['slip']->id }}" x-cloak class="modal-backdrop" @click.self="pay = null">
    <form method="post" action="{{ route('app.payroll.pay', $r['slip']) }}" class="modal-panel space-y-4">@csrf
        <h3 class="text-xl font-semibold">Ish haqi to'lash: {{ $r['employee']->full_name }}</h3>
        <p class="text-sm font-medium text-ink-soft">Qolgan summa: {{ money($r['slip']->remaining()) }} so'm</p>
        <div><label class="label">Summa (so'm)</label><input name="amount" x-ref="amt{{ $r['slip']->id }}" value="{{ $r['slip']->remaining() }}" inputmode="numeric" class="input text-xl font-semibold" required></div>
        <div><label class="label">Qaysi hisobdan</label><select name="account" class="select">@foreach($accounts as $a)<option value="{{ $a }}">{{ $accLabels[$a] }} ({{ money($balances[$a]) }})</option>@endforeach</select></div>
        <div class="flex gap-3 justify-end"><button type="button" class="btn" @click="pay=null">Bekor qilish</button><button class="btn btn-primary">To'lash</button></div>
    </form>
</div>
@endif @endforeach
@endcan
</div>
@endsection
