@extends('layouts.app')
@section('title', __('Bolalar davomadi'))
@section('content')
<form method="get" class="flex flex-wrap items-end gap-3 mb-5">
    <div><label class="label">{{ __('Guruh') }}</label>
        <select name="group" class="select !w-64" onchange="this.form.submit()">@foreach($groups as $g)<option value="{{ $g->id }}" @selected($group?->id===$g->id)>{{ $g->name }}@if($g->type!=='main') — {{ __($g->typeLabel()) }}@endif</option>@endforeach</select></div>
    <div><label class="label">{{ __('Sana') }}</label><input type="date" name="date" value="{{ $date->toDateString() }}" max="{{ today()->toDateString() }}" class="input !w-44" onchange="this.form.submit()"></div>
    @if($group?->type === 'saturday')<a href="{{ route('app.attendance.index', ['group' => $group->id, 'date' => $lastSaturday->toDateString()]) }}" class="btn btn-sm">{{ __('Oxirgi shanba') }}: {{ $lastSaturday->format('d.m') }}</a>@endif
</form>
@if (! $group)
    <div class="empty"><x-icon name="attendance" class="size-10" /><p class="font-medium mt-2">{{ __('Guruh topilmadi') }}</p><a href="{{ route('app.groups.create') }}" class="btn btn-accent btn-sm mt-3">{{ __('Guruh yarating') }}</a></div>
@else
    @if($group->isDaily())
        <div class="banner banner-info mb-4 max-w-3xl"><x-icon name="info" /><p class="flex-1">{{ __($group->typeLabel()) }}@if($group->timeLabel()) ({{ $group->timeLabel() }})@endif. {{ __('Faqat «Keldi» belgilangan kun uchun bolaning hisobidan :fee yechiladi.', ['fee' => money($group->daily_fee).' '.__("so'm")]) }}</p></div>
    @endif
    @if($wrongDay)
        <div class="banner banner-warn mb-4 max-w-3xl"><x-icon name="clock" /><p>{{ __('Shanba guruhi davomadi faqat shanba kuni belgilanadi. Sanani shanbaga o\'zgartiring.') }}</p></div>
    @else
        <x-attendance-list :rows="$rows" :payload="['group_id' => $group->id]" :date="$date->toDateString()" :locked="$locked" :url="route('app.attendance.store')" :lock-days="$lockDays" />
    @endif
    @if($group->isDaily() && $available->isNotEmpty() && ! $wrongDay)
        <form method="post" action="{{ route('app.attendance.attach') }}" class="max-w-3xl mt-5 card card-pad flex flex-wrap items-end gap-3">@csrf
            <input type="hidden" name="group_id" value="{{ $group->id }}"><input type="hidden" name="date" value="{{ $date->toDateString() }}">
            <div class="flex-1 min-w-56"><label class="label">{{ __("Ro'yxatda yo'q bolani qo'shish") }}</label>
                <select name="kid_id" class="select">@foreach($available as $k)<option value="{{ $k->id }}">{{ $k->full_name }}</option>@endforeach</select></div>
            <button class="btn btn-sm">{{ __("Qo'shish") }}</button>
        </form>
    @endif
@endif
@endsection
