@extends('layouts.public')
@php
    $titles = ['oferta' => 'Ommaviy oferta', 'privacy' => 'Maxfiylik siyosati', 'terms' => 'Foydalanish shartlari'];
@endphp
@section('title', $titles[$page])
@section('content')
<article class="max-w-3xl mx-auto px-4 py-12 prose-kd">
    <h1>{{ $titles[$page] }}</h1>
    <p class="banner banner-warn">Bu matn namuna (shablon). Ishga tushirishdan oldin yurist bilan kelishib, o'z rekvizitlaringiz va shartlaringizni kiriting.</p>
    @if ($page === 'oferta')
        <h2>1. Umumiy qoidalar</h2>
        <p>KinderDesk — xususiy bog'chalar uchun onlayn boshqaruv xizmati. Ro'yxatdan o'tish orqali foydalanuvchi ushbu shartlarga rozilik bildiradi.</p>
        <h2>2. Xizmat va to'lov</h2>
        <p>Yangi bog'cha {{ config('kinderdesk.trial_days') }} kunlik bepul sinov oladi. Keyin xizmatdan to'liq foydalanish uchun obuna (1, 3 yoki 12 oy) xarid qilinadi. Obuna tugasa, tizim faqat ko'rish rejimiga o'tadi, ma'lumotlar saqlanadi.</p>
        <p>Karta orqali to'langan summa tasdiqlangandan so'ng bog'cha balansiga to'liq tushadi. Balansdagi mablag' obuna uchun sarflanadi.</p>
        <h2>3. Ma'lumotlarni o'chirish</h2>
        <p>Obuna tugaganidan {{ config('kinderdesk.delete_after_days') }} kun o'tib to'lanmasa, bog'cha ma'lumotlari o'chirilishi mumkin. O'chirilgan ma'lumotlarni qaytarib bo'lmaydi.</p>
    @elseif ($page === 'privacy')
        <h2>Qanday ma'lumot yig'iladi</h2>
        <p>Bog'cha va xodimlar haqida (ism, telefon), bolalar va ota-onalar ma'lumotlari — faqat bog'chaning o'zi kiritadi va faqat o'sha bog'cha ko'ra oladi.</p>
        <h2>Foydalanish va saqlash</h2>
        <p>Ma'lumotlar xizmatni ko'rsatish uchun ishlatiladi, uchinchi shaxslarga sotilmaydi. SMS xabarlar Eskiz orqali yuboriladi.</p>
        <h2>Huquqlaringiz</h2>
        <p>Istalgan vaqtda ma'lumotlaringizni ko'chirib olish yoki o'chirishni so'rashingiz mumkin.</p>
    @else
        <h2>Foydalanish shartlari</h2>
        <p>Hisob ma'lumotlarini sir saqlang. Tizimdan qonunga zid maqsadda foydalanish taqiqlanadi. Bir telefon raqam, email yoki STIR uchun bepul sinov faqat bir marta beriladi.</p>
    @endif
</article>
@endsection
