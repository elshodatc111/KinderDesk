@extends('layouts.public')
@section('title', "Bog'changiz uchun yagona boshqaruv")
@section('content')

{{-- ============ Hero: bloklardan minora ============ --}}
<section class="relative overflow-hidden paper-dots">
    <div class="max-w-6xl mx-auto px-4 pt-14 pb-20 grid lg:grid-cols-[1.1fr_.9fr] gap-12 items-center">
        <div>
            <h1 class="font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.05] text-balance">Bog'cha ishi tartibga tushsa, bolalarga vaqt qoladi</h1>
            <p class="mt-5 text-lg font-semibold text-ink-soft max-w-xl text-pretty">Bolalar, davomad, to'lovlar, ish haqi va ota-onalarga SMS — hammasi bitta joyda. Har bir bog'cha tizimni o'ziga moslaydi: keraksiz bo'limni o'chiradi, kerakligini qo'shadi.</p>
            <div class="mt-8 flex flex-wrap gap-3">
                <a href="{{ route('register') }}" class="btn btn-accent btn-lg">{{ $trialDays }} kun bepul sinab ko'ring</a>
                <a href="#nashrlar" class="btn btn-lg">Nashrlarni ko'rish</a>
            </div>
            <p class="mt-4 text-sm font-medium text-ink-mute">Karta shart emas. Sinov tugagach ma'lumotlaringiz saqlanadi, tizim ko'rish rejimiga o'tadi.</p>
        </div>

        <div class="relative mx-auto w-full max-w-md select-none" aria-hidden="true">
            @php
                $blocks = [
                    ['Bolalar', 'var(--color-berry-500)', '#fff', '-2deg', '0s', '11rem'],
                    ['Davomad', 'var(--color-leaf-500)', '#1a1a1a', '2deg', '.15s', '13rem'],
                    ["To'lov", 'var(--color-sun-500)', '#1a1a1a', '-1deg', '.3s', '12rem'],
                    ['Ish haqi', 'var(--color-sky-500)', '#fff', '3deg', '.45s', '14rem'],
                    ['SMS', 'var(--color-grape-500)', '#fff', '-3deg', '.6s', '10rem'],
                ];
            @endphp
            <div class="flex flex-col-reverse items-center gap-2 pt-6">
                <div class="h-3 w-72 rounded-full bg-ink/80 mt-1"></div>
                @foreach ($blocks as [$t, $bg, $fg, $rot, $d, $w])
                    <div class="tower-block rounded-2xl border border-line px-5 py-4 text-center font-semibold text-xl"
                         style="--r1:{{ $rot }};--d:{{ $d }};width:{{ $w }};background:{{ $bg }};color:{{ $fg }};box-shadow:4px 4px 0 0 var(--color-ink)">{{ $t }}</div>
                @endforeach
            </div>
        </div>
    </div>
</section>

{{-- ============ Imkoniyatlar ============ --}}
<section id="imkoniyatlar" class="max-w-6xl mx-auto px-4 py-16 scroll-mt-20">
    <h2 class="font-display text-3xl sm:text-4xl font-semibold max-w-2xl text-balance">Kundalik ishning hammasi — bitta oynada</h2>
    <div class="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        @php
            $cards = [
                ['kids', 'berry', 'Bolalar va guruhlar', "Ota-ona ma'lumotlari, guruhga qabul, qarz va to'lov tarixi bir kartada."],
                ['attendance', 'leaf', 'Davomad', "Tarbiyachi telefondan belgilaydi. Internet uzilsa ham saqlanadi va keyin yuboriladi."],
                ['wallet', 'marigold', "Kassa va to'lovlar", "Kim qancha to'ladi, kimda qarz bor — real vaqtda. Har bir so'm hisobda."],
                ['cash', 'sky', 'Ish haqi', "Qat'iy oylik, davomad bo'yicha yoki aralash — bog'changiz usulini tanlang."],
                ['sms', 'grape', 'SMS xabarlar', "O'z Eskiz hisobingiz bilan. Qaysi holatda yuborilishini o'zingiz belgilaysiz."],
                ['inbox', 'sun', 'Arizalar', "Ochiq forma havolasini ulashing — arizalar voronkaga o'zi tushadi."],
            ];
        @endphp
        @foreach ($cards as [$icon, $color, $title, $text])
            <div class="card-sticker p-6" style="{{ \App\Support\Navigation::colors($color) }}">
                <span class="nav-block !size-12 mb-4"><x-icon :name="$icon" class="size-6" /></span>
                <h3 class="text-lg font-semibold">{{ $title }}</h3>
                <p class="mt-1.5 font-semibold text-ink-soft text-pretty">{{ $text }}</p>
            </div>
        @endforeach
    </div>
</section>

{{-- ============ Qanday boshlanadi (ketma-ketlik) ============ --}}
<section class="bg-teal-50 border-y-2 border-line">
    <div class="max-w-6xl mx-auto px-4 py-16">
        <h2 class="font-display text-3xl sm:text-4xl font-semibold">Uch qadamda ishga tushadi</h2>
        <ol class="mt-10 grid md:grid-cols-3 gap-6">
            @foreach ([["Ro'yxatdan o'ting", "Telefon raqamingizni SMS kod bilan tasdiqlang va nashrni tanlang."], ["Bog'chani moslang", "Guruhlar, xodimlar, narxlar va kerakli bo'limlarni sozlang."], ["Ishlashni boshlang", "Bolalarni kiriting, davomad va to'lovlarni yuriting."]] as $i => [$t, $d])
                <li class="card p-6 relative">
                    <span class="absolute -top-4 -left-2 grid place-items-center size-10 rounded-full bg-marigold-500 border border-line font-semibold">{{ $i + 1 }}</span>
                    <h3 class="font-semibold text-lg mt-2">{{ $t }}</h3><p class="font-semibold text-ink-soft mt-1">{{ $d }}</p>
                </li>
            @endforeach
        </ol>
    </div>
</section>

{{-- ============ Nashrlar va narxlar ============ --}}
<section id="nashrlar" class="max-w-6xl mx-auto px-4 py-16 scroll-mt-20" x-data="{ months: 3 }">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h2 class="font-display text-3xl sm:text-4xl font-semibold">Bog'changizga mos nashrni tanlang</h2>
            <p class="mt-2 font-semibold text-ink-soft">Hammasida {{ $trialDays }} kunlik bepul sinov. Nashrni keyin almashtirish mumkin.</p>
        </div>
        <div class="tabs" id="narxlar" role="tablist" aria-label="Obuna muddati">
            @foreach ([1 => '1 oy', 3 => '3 oy', 12 => '1 yil'] as $m => $l)
                <button type="button" role="tab" class="tab" :class="months === {{ $m }} && 'is-active'" @click="months = {{ $m }}" :aria-selected="months === {{ $m }}">{{ $l }}</button>
            @endforeach
        </div>
    </div>

    <div class="mt-10 grid lg:grid-cols-3 gap-6 items-stretch">
        @foreach ($editions as $ed)
            @php $featured = $ed->key === 'standard'; @endphp
            <div class="card-sticker p-6 flex flex-col relative {{ $featured ? 'lg:-mt-3 lg:mb-3' : '' }}" style="{{ $featured ? 'background:var(--color-sun-50)' : '' }}">
                @if ($featured)<span class="badge badge-orange absolute -top-3 right-5">Ko'pchilik tanlaydi</span>@endif
                <h3 class="text-2xl font-semibold">{{ $ed->name }}</h3>
                <p class="font-semibold text-ink-soft mt-1 min-h-12">{{ $ed->tagline }}</p>
                <div class="mt-5">
                    @foreach ($ed->plans as $plan)
                        <div x-show="months === {{ $plan->months }}" @if(!$loop->first) x-cloak @endif>
                            <p class="text-4xl font-semibold tracking-tight">{{ money($plan->price) }} <span class="text-base font-medium text-ink-mute">so'm</span></p>
                            <p class="text-sm font-medium text-ink-soft mt-1">{{ $plan->label() }} uchun
                                @if ($plan->months > 1) · oyiga {{ money($plan->monthlyEquivalent()) }} so'm @endif</p>
                        </div>
                    @endforeach
                </div>
                <ul class="mt-6 space-y-2 flex-1">
                    @foreach ($features as $key => $f)
                        @continue(!empty($f['core']) && false)
                        @php $has = in_array($key, $ed->features ?? []); @endphp
                        <li class="flex items-start gap-2.5 font-medium {{ $has ? '' : 'text-ink-mute line-through decoration-1' }}">
                            <x-icon :name="$has ? 'check' : 'x'" class="size-5 mt-0.5 shrink-0 {{ $has ? 'text-leaf-700' : 'text-ink-mute' }}" />
                            <span>{{ $f['label'] }}</span>
                        </li>
                    @endforeach
                </ul>
                <a href="{{ route('register', ['edition' => $ed->key]) }}" class="btn {{ $featured ? 'btn-accent' : 'btn-primary' }} btn-lg btn-block mt-7">Bepul boshlash</a>
            </div>
        @endforeach
    </div>
    <p class="text-sm font-medium text-ink-mute mt-6">To'lov Payme yoki karta orqali (chek yuborib). Summa to'liq bog'cha balansiga tushadi.</p>
</section>

{{-- ============ Savollar ============ --}}
<section id="savollar" class="max-w-3xl mx-auto px-4 py-12 scroll-mt-20">
    <h2 class="font-display text-3xl font-semibold mb-6">Ko'p beriladigan savollar</h2>
    <div class="space-y-3" x-data="{ open: 0 }">
        @foreach ([
            ["Sinov tugagach nima bo'ladi?", "Tizim faqat ko'rish rejimiga o'tadi: ma'lumotlaringiz joyida, lekin yangi yozuv kirita olmaysiz. Obunani faollashtirsangiz, ish davom etadi."],
            ["Ma'lumotlarim boshqa bog'chalarga ko'rinadimi?", "Yo'q. Har bir bog'chaning ma'lumoti butunlay alohida, faqat o'z xodimlaringiz ko'ra oladi."],
            ["Obuna tugashiga oldin ogohlantirasizmi?", "Ha. Tugashiga 3 kun qolganda direktorga ilova ichida va SMS orqali xabar boradi. Balansda mablag' bo'lsa, obuna o'zi yangilanadi."],
            ["Bepul sinovni qayta olsam bo'ladimi?", "Yo'q. Bir telefon raqam, email yoki STIR uchun sinov faqat bir marta beriladi."],
            ["SMS qanday yuboriladi?", "Bog'changiz o'z Eskiz hisobini ulaydi. Qaysi holatda SMS ketishini sozlamalardan belgilaysiz; matnlar Eskiz tasdig'idan o'tgach ishlaydi."],
        ] as $i => [$q, $a])
            <div class="card">
                <button type="button" class="w-full flex items-center justify-between gap-4 text-left px-5 py-4 font-semibold" @click="open = open === {{ $i + 1 }} ? 0 : {{ $i + 1 }}" :aria-expanded="open === {{ $i + 1 }}">
                    {{ $q }} <x-icon name="chevron-down" class="size-5 shrink-0 transition" ::class="open === {{ $i + 1 }} && 'rotate-180'" />
                </button>
                <p x-show="open === {{ $i + 1 }}" x-cloak class="px-5 pb-4 font-semibold text-ink-soft">{{ $a }}</p>
            </div>
        @endforeach
    </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10">
    <div class="card-sticker p-8 sm:p-12 text-center" style="background:var(--color-teal-600);color:#fff;box-shadow:6px 6px 0 0 var(--color-marigold-500)">
        <h2 class="font-display text-3xl sm:text-4xl font-semibold text-balance !text-white">Bugun boshlang — {{ $trialDays }} kun hammasi bepul</h2>
        <a href="{{ route('register') }}" class="btn btn-accent btn-lg mt-6">Ro'yxatdan o'tish</a>
    </div>
</section>
@endsection
