@extends('layouts.admin')
@section('title', 'Platforma sozlamalari')
@section('content')
<div class="grid lg:grid-cols-2 gap-6">
    <form method="post" action="{{ route('admin.settings.update') }}" class="card card-pad space-y-4">@csrf @method('put')
        <h2 class="section-title">To'lov: karta ma'lumotlari</h2>
        <p class="help">Payme ulanmagan bog'chalar shu kartaga o'tkazma qilib, chekni yuboradi.</p>
        <div><label class="label">Karta raqami</label><input name="payment_card_number" class="input" value="{{ $values['payment.card_number'] }}" inputmode="numeric"></div>
        <div class="grid grid-cols-2 gap-3">
            <div><label class="label">Karta egasi</label><input name="payment_card_holder" class="input" value="{{ $values['payment.card_holder'] }}"></div>
            <div><label class="label">Bank</label><input name="payment_card_bank" class="input" value="{{ $values['payment.card_bank'] }}"></div></div>
        <div><label class="label">Eng kam to'lov (so'm)</label><input name="payment_min_topup" type="number" class="input" value="{{ $values['payment.min_topup'] }}"></div>
        <div><label class="label">Bog'chaga ko'rsatiladigan izoh</label><textarea name="payment_note" class="textarea" rows="2">{{ $values['payment.note'] }}</textarea></div>
        <h2 class="section-title pt-2">Qo'llab-quvvatlash</h2>
        <div class="grid grid-cols-2 gap-3">
            <div><label class="label">Telefon</label><input name="support_phone" class="input" value="{{ $values['support.phone'] }}"></div>
            <div><label class="label">Telegram</label><input name="support_telegram" class="input" value="{{ $values['support.telegram'] }}"></div></div>
        <button class="btn btn-primary">Saqlash</button>
    </form>

    <div class="space-y-6">
        <div class="card card-pad space-y-3">
            <h2 class="section-title">Ulanishlar holati</h2>
            <div class="flex items-center justify-between"><span class="font-medium">Payme</span>
                @if($paymeEnabled)<span class="badge badge-leaf">Ulangan {{ $paymeTest ? '(sinov rejimi)' : '' }}</span>@else<span class="badge badge-gray">Ulanmagan: faqat karta + chek</span>@endif</div>
            <div class="flex items-center justify-between"><span class="font-medium">Eskiz (platforma)</span>
                @if($smsDriver==='eskiz' && $eskizConfigured)<span class="badge badge-leaf">Yoqilgan</span>@else<span class="badge badge-orange">Sinov rejimi: SMS yuborilmaydi, kod logga yoziladi</span>@endif</div>
            <form method="post" action="{{ route('admin.settings.eskiz-check') }}">@csrf <button class="btn btn-sm">Eskiz ulanishini tekshirish</button></form>
            <p class="help">Payme va Eskiz kalitlari xavfsizlik uchun faqat <code>.env</code> faylida saqlanadi.</p>
        </div>
    </div>
</div>

<section class="mt-8">
    <div class="flex flex-wrap items-center justify-between gap-3 mb-3">
        <h2 class="section-title">Platforma SMS shablonlari (login, kod, direktor ogohlantirishlari)</h2>
        <form method="post" action="{{ route('admin.settings.templates.sync') }}">@csrf <button class="btn btn-sm"><x-icon name="refresh" /> Eskiz holatini tekshirish</button></form>
    </div>
    <div class="grid lg:grid-cols-2 gap-4">
    @foreach ($templates as $t)
        @php $badge = ['draft'=>'badge-gray','pending'=>'badge-orange','approved'=>'badge-leaf','rejected'=>'badge-red'][$t->status] ?? 'badge-gray'; @endphp
        <div class="card card-pad space-y-3">
            <div class="flex items-center justify-between"><h3 class="font-semibold">{{ $t->name }}</h3><span class="badge {{ $badge }}">{{ $t->statusLabel() }}</span></div>
            <form method="post" action="{{ route('admin.settings.templates.update', $t) }}" class="space-y-2">@csrf @method('put')
                <textarea name="body" rows="3" class="textarea">{{ $t->body }}</textarea>
                <p class="help">O'zgaruvchilar: {{ collect($events[$t->event_key]['vars'] ?? [])->map(fn($v) => '{'.$v.'}')->implode(' ') }}</p>
                <button class="btn btn-sm">Matnni saqlash</button>
            </form>
            @if($t->rejection_reason)<p class="text-sm font-medium text-danger">{{ $t->rejection_reason }}</p>@endif
            <div class="flex flex-wrap gap-2 items-center border-t border-line pt-3">
                <form method="post" action="{{ route('admin.settings.templates.submit', $t) }}">@csrf <button class="btn btn-sm btn-primary" @disabled($t->status==='pending'||$t->status==='approved')>Eskizga tasdiqlashga yuborish</button></form>
                <form method="post" action="{{ route('admin.settings.templates.test', $t) }}" class="flex gap-2">@csrf <input name="phone" class="input !w-36 !py-1" placeholder="90 123 45 67" required><button class="btn btn-sm">Sinov SMS</button></form>
            </div>
        </div>
    @endforeach
    </div>
    @if ($logs->isNotEmpty())
    <div class="card table-wrap mt-5"><div class="table-scroll"><table class="table"><thead><tr><th>Vaqt</th><th>Kimga</th><th>Hodisa</th><th>Holat</th></tr></thead><tbody>
        @foreach ($logs as $l)<tr><td>{{ $l->created_at->format('d.m H:i') }}</td><td>{{ format_phone($l->to) }}</td><td>{{ $l->event_key }}</td><td><span class="badge {{ in_array($l->status,['sent','delivered'])?'badge-leaf':($l->status==='failed'?'badge-red':'badge-gray') }}">{{ $l->status }}</span> <span class="text-xs text-ink-soft">{{ $l->error }}</span></td></tr>@endforeach
    </tbody></table></div></div>@endif
</section>
@endsection
