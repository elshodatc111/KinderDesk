<?php

use Illuminate\Support\Facades\Schedule;

// Har kuni yarim tundan keyin (Toshkent vaqti): obuna tekshiruvi, avto-yangilash, eslatmalar
Schedule::command('subscriptions:process')->dailyAt('00:05')->withoutOverlapping();
// Kun davomida ham tekshirib turamiz (masalan, to'lov tushgandan keyin kechikib qolgan eslatmalar uchun)
Schedule::command('subscriptions:process')->hourlyAt(30)->withoutOverlapping();

// Bolalar oylik to'lovini hisoblash (har kuni tekshiriladi, takrorlanmaydi)
Schedule::command('kids:charge')->dailyAt('01:00')->withoutOverlapping();

// Tug'ilgan kun tabriklari (09:00 Toshkent vaqti)
Schedule::command('kids:birthdays')->dailyAt('09:00')->withoutOverlapping();

// Server holati signallari (super admin → "Tizim holati")
Schedule::call(fn () => \Illuminate\Support\Facades\Cache::put('kd:health:scheduler', now()->toIso8601String(), 3600))->everyMinute()->name('kd-heartbeat');
Schedule::job(new \App\Jobs\WorkerHeartbeat)->everyMinute();
