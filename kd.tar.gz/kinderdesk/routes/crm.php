<?php

use App\Http\Controllers\App as C;
use Illuminate\Support\Facades\Route;

/* CRM bo'limlari. Prefiks: /app, nomlar: app.* */

// ----- Yo'riqnoma (hamma foydalanuvchi uchun) -----
Route::get('/yoriqnoma', [C\GuideController::class, 'index'])->name('guide');

// ----- Guruhlar -----
Route::middleware('feature:groups')->group(function () {
    Route::get('/guruhlar', [C\GroupController::class, 'index'])->middleware('can:groups.view')->name('groups.index');
    Route::middleware('can:groups.manage')->group(function () {
        Route::get('/guruhlar/yangi', [C\GroupController::class, 'create'])->name('groups.create');
        Route::post('/guruhlar', [C\GroupController::class, 'store'])->name('groups.store');
        Route::get('/guruhlar/{group}/tahrirlash', [C\GroupController::class, 'edit'])->name('groups.edit');
        Route::put('/guruhlar/{group}', [C\GroupController::class, 'update'])->name('groups.update');
        Route::post('/guruhlar/{group}/arxiv', [C\GroupController::class, 'archive'])->name('groups.archive');
        Route::post('/guruhlar/{group}/xodim', [C\GroupController::class, 'assignEmployee'])->name('groups.employees.assign');
        Route::delete('/guruhlar/{group}/xodim/{link}', [C\GroupController::class, 'removeEmployee'])->name('groups.employees.remove');
        Route::post('/guruhlar/{group}/bola', [C\GroupController::class, 'enrollKid'])->name('groups.kids.enroll');
        Route::delete('/guruhlar/{group}/bola/{link}', [C\GroupController::class, 'leaveKid'])->name('groups.kids.leave');
    });
    Route::get('/guruhlar/{group}', [C\GroupController::class, 'show'])->middleware('can:groups.view')->name('groups.show');
});

// ----- Bolalar -----
Route::middleware('feature:kids')->group(function () {
    Route::get('/bolalar', [C\KidController::class, 'index'])->middleware('can:kids.view')->name('kids.index');
    Route::middleware('can:kids.manage')->group(function () {
        Route::get('/bolalar/yangi', [C\KidController::class, 'create'])->name('kids.create');
        Route::post('/bolalar', [C\KidController::class, 'store'])->name('kids.store');
        Route::get('/bolalar/{kid}/tahrirlash', [C\KidController::class, 'edit'])->name('kids.edit');
        Route::put('/bolalar/{kid}', [C\KidController::class, 'update'])->name('kids.update');
        Route::post('/bolalar/{kid}/otkazish', [C\KidController::class, 'transfer'])->name('kids.transfer');
        Route::post('/bolalar/{kid}/qoshimcha', [C\KidController::class, 'addExtra'])->name('kids.extra.add');
        Route::post('/bolalar/{kid}/arxiv', [C\KidController::class, 'archive'])->name('kids.archive');
        Route::post('/bolalar/{kid}/qayta-qabul', [C\KidController::class, 'restore'])->name('kids.restore');
        Route::post('/bolalar/{kid}/izoh', [C\KidController::class, 'note'])->name('kids.notes.store');
        Route::delete('/bolalar/{kid}/izoh/{note}', [C\KidController::class, 'noteDestroy'])->name('kids.notes.destroy');
    });
    Route::middleware(['feature:desk', 'can:finance.payments'])->group(function () {
        Route::post('/bolalar/{kid}/tolov', [C\KidPaymentController::class, 'payment'])->name('kids.payment');
        Route::post('/bolalar/{kid}/qaytarish', [C\KidPaymentController::class, 'refund'])->name('kids.refund');
        Route::post('/bolalar/{kid}/tuzatish', [C\KidPaymentController::class, 'adjust'])->name('kids.adjust');
    });
    Route::get('/bolalar/{kid}', [C\KidController::class, 'show'])->middleware('can:kids.view')->name('kids.show');
});

// ----- Xodimlar -----
Route::middleware('feature:employees')->group(function () {
    Route::get('/xodimlar', [C\EmployeeController::class, 'index'])->middleware('can:employees.view')->name('employees.index');
    Route::middleware('can:employees.manage')->group(function () {
        Route::get('/xodimlar/yangi', [C\EmployeeController::class, 'create'])->name('employees.create');
        Route::post('/xodimlar', [C\EmployeeController::class, 'store'])->name('employees.store');
        Route::get('/xodimlar/{employee}/tahrirlash', [C\EmployeeController::class, 'edit'])->name('employees.edit');
        Route::put('/xodimlar/{employee}', [C\EmployeeController::class, 'update'])->name('employees.update');
        Route::post('/xodimlar/{employee}/arxiv', [C\EmployeeController::class, 'archive'])->name('employees.archive');
        Route::post('/xodimlar/{employee}/izoh', [C\EmployeeController::class, 'note'])->name('employees.notes.store');
    });
    Route::get('/xodimlar/{employee}', [C\EmployeeController::class, 'show'])->middleware('can:employees.view')->name('employees.show');
});

// ----- Sozlamalar -----
Route::middleware('can:settings.manage')->prefix('sozlamalar')->name('settings.')->group(function () {
    Route::get('/', [C\SettingsController::class, 'index'])->name('index');
    Route::put('/', [C\SettingsController::class, 'update'])->name('update');
    Route::post('/bolimlar', [C\SettingsController::class, 'modules'])->name('modules');
    Route::post('/bogcha', [C\SettingsController::class, 'organization'])->name('organization');
    Route::post('/foydalanuvchilar', [C\SettingsController::class, 'userStore'])->name('users.store');
    Route::put('/foydalanuvchilar/{user}', [C\SettingsController::class, 'userUpdate'])->name('users.update');
    Route::delete('/foydalanuvchilar/{user}', [C\SettingsController::class, 'userDestroy'])->name('users.destroy');
    Route::middleware('can:roles.manage')->group(function () {
        Route::get('/lavozimlar/yangi', [C\SettingsController::class, 'roleCreate'])->name('roles.create');
        Route::post('/lavozimlar', [C\SettingsController::class, 'roleStore'])->name('roles.store');
        Route::get('/lavozimlar/{role}', [C\SettingsController::class, 'roleEdit'])->name('roles.edit');
        Route::put('/lavozimlar/{role}', [C\SettingsController::class, 'roleUpdate'])->name('roles.update');
        Route::delete('/lavozimlar/{role}', [C\SettingsController::class, 'roleDestroy'])->name('roles.destroy');
    });
});

// ----- Davomad -----
Route::middleware('feature:attendance')->group(function () {
    Route::get('/davomad', [C\AttendanceController::class, 'index'])->middleware('can:attendance.kids')->name('attendance.index');
    Route::post('/davomad', [C\AttendanceController::class, 'store'])->middleware('can:attendance.kids')->name('attendance.store');
    Route::post('/davomad/qoshish', [C\AttendanceController::class, 'attach'])->middleware('can:attendance.kids')->name('attendance.attach');
});
Route::middleware('feature:staff_attendance')->group(function () {
    Route::get('/xodimlar-davomadi', [C\AttendanceController::class, 'staff'])->middleware('can:attendance.staff')->name('staff-attendance.index');
    Route::post('/xodimlar-davomadi', [C\AttendanceController::class, 'staffStore'])->middleware('can:attendance.staff')->name('staff-attendance.store');
});

// ----- Kassa (bog'cha) -----
Route::middleware(['feature:desk'])->prefix('kassa')->name('desk.')->group(function () {
    Route::get('/', [C\DeskController::class, 'index'])->middleware('can:desk.view')->name('index');
    Route::get('/bolalar', [C\DeskController::class, 'kids'])->middleware('can:finance.payments')->name('kids');
    Route::post('/xarajat', [C\DeskController::class, 'expense'])->middleware('can:finance.expenses')->name('expense');
    Route::post('/topshirish', [C\DeskController::class, 'handover'])->middleware('can:desk.handover')->name('handover');
    Route::post('/hisoblash', [C\DeskController::class, 'charge'])->middleware('can:finance.payments')->name('charge');
    Route::post('/{transaction}/tasdiqlash', [C\DeskController::class, 'confirm'])->middleware('can:finance.confirm')->name('confirm');
    Route::post('/{transaction}/bekor', [C\DeskController::class, 'cancel'])->middleware('can:finance.confirm')->name('cancel');
});

// ----- Moliya (direktor hisobi) -----
Route::middleware(['feature:finance'])->prefix('moliya')->name('finance.')->group(function () {
    Route::get('/', [C\FinanceController::class, 'index'])->middleware('can:finance.view')->name('index');
    Route::middleware('can:finance.expenses')->group(function () {
        Route::post('/yozuv', [C\FinanceController::class, 'store'])->name('store');
        Route::post('/otkazma', [C\FinanceController::class, 'transfer'])->name('transfer');
    });
    Route::middleware('can:finance.handover')->group(function () {
        Route::post('/topshirish/{handover}/qabul', [C\FinanceController::class, 'handoverConfirm'])->name('handover.confirm');
        Route::post('/topshirish/{handover}/rad', [C\FinanceController::class, 'handoverReject'])->name('handover.reject');
    });
});

// ----- To'garaklar -----
Route::middleware('feature:clubs')->prefix('togaraklar')->name('clubs.')->group(function () {
    Route::get('/', [C\ClubController::class, 'index'])->middleware('can:clubs.view')->name('index');
    Route::middleware('can:clubs.manage')->group(function () {
        Route::get('/yangi', [C\ClubController::class, 'create'])->name('create');
        Route::post('/', [C\ClubController::class, 'store'])->name('store');
        Route::get('/{club}/tahrirlash', [C\ClubController::class, 'edit'])->name('edit');
        Route::put('/{club}', [C\ClubController::class, 'update'])->name('update');
        Route::post('/{club}/arxiv', [C\ClubController::class, 'archive'])->name('archive');
        Route::post('/{club}/bola', [C\ClubController::class, 'enroll'])->name('enroll');
        Route::delete('/{club}/bola/{link}', [C\ClubController::class, 'leave'])->name('leave');
    });
    Route::post('/{club}/davomad', [C\ClubController::class, 'attendance'])->middleware('can:attendance.kids')->name('attendance');
    Route::get('/{club}', [C\ClubController::class, 'show'])->middleware('can:clubs.view')->name('show');
});

// ----- Hisobotlar -----
Route::middleware(['feature:reports', 'can:reports.view'])->prefix('hisobotlar')->name('reports.')->group(function () {
    Route::get('/', [C\ReportController::class, 'index'])->name('index');
    Route::get('/yuklab-olish/{what}', [C\ReportController::class, 'export'])->name('export');
});

// ----- Ish haqi -----
Route::middleware(['feature:payroll', 'can:payroll.view'])->prefix('ish-haqi')->name('payroll.')->group(function () {
    Route::get('/', [C\PayrollController::class, 'index'])->name('index');
    Route::middleware('can:payroll.manage')->group(function () {
        Route::post('/hisoblash', [C\PayrollController::class, 'generate'])->name('generate');
        Route::post('/{payslip}/qayta', [C\PayrollController::class, 'recalc'])->name('recalc');
        Route::put('/{payslip}', [C\PayrollController::class, 'adjust'])->name('adjust');
        Route::post('/{payslip}/tolash', [C\PayrollController::class, 'pay'])->name('pay');
        Route::delete('/{payslip}', [C\PayrollController::class, 'destroy'])->name('destroy');
    });
});

// ----- Arizalar -----
Route::middleware('feature:leads')->prefix('arizalar')->name('leads.')->group(function () {
    Route::get('/', [C\LeadController::class, 'index'])->middleware('can:leads.view')->name('index');
    Route::middleware('can:leads.manage')->group(function () {
        Route::post('/', [C\LeadController::class, 'store'])->name('store');
        Route::post('/{lead}/holat', [C\LeadController::class, 'move'])->name('move');
        Route::put('/{lead}', [C\LeadController::class, 'update'])->name('update');
        Route::delete('/{lead}', [C\LeadController::class, 'destroy'])->name('destroy');
    });
});

// ----- SMS -----
Route::middleware(['feature:sms', 'can:sms.manage'])->prefix('sms')->name('sms.')->group(function () {
    Route::get('/', [C\SmsController::class, 'index'])->name('index');
    Route::post('/akkaunt', [C\SmsController::class, 'saveAccount'])->name('account');
    Route::post('/akkaunt/tekshirish', [C\SmsController::class, 'checkAccount'])->name('account.check');
    Route::delete('/akkaunt', [C\SmsController::class, 'removeAccount'])->name('account.remove');
    Route::post('/qoidalar', [C\SmsController::class, 'saveRules'])->name('rules');
    Route::post('/shablonlar', [C\SmsController::class, 'templateStore'])->name('templates.store');
    Route::post('/shablonlar/holat', [C\SmsController::class, 'templatesSync'])->name('templates.sync');
    Route::put('/shablonlar/{template}', [C\SmsController::class, 'templateUpdate'])->name('templates.update');
    Route::post('/shablonlar/{template}/yuborish', [C\SmsController::class, 'templateSubmit'])->name('templates.submit');
    Route::post('/shablonlar/{template}/sinov', [C\SmsController::class, 'templateTest'])->name('templates.test');
    Route::delete('/shablonlar/{template}', [C\SmsController::class, 'templateDestroy'])->name('templates.destroy');
    Route::post('/ommaviy', [C\SmsController::class, 'bulk'])->name('bulk');
    Route::post('/qarz-eslatma', [C\SmsController::class, 'debtReminders'])->name('debts');
});
