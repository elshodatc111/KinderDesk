<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\App as AppC;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Public\HomeController;
use App\Http\Controllers\Shared\NotificationController;
use App\Http\Controllers\Webhooks;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/* ============ Ommaviy sahifalar ============ */
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/huquqiy/{page}', [HomeController::class, 'legal'])->name('legal');
Route::get('/til/{locale}', [HomeController::class, 'locale'])->name('locale');

/* ============ Kirish / ro'yxatdan o'tish ============ */
Route::middleware('guest')->group(function () {
    Route::get('/kirish', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/kirish', [AuthController::class, 'login'])->middleware('throttle:login')->name('login.attempt');
    Route::post('/kirish/kod', [AuthController::class, 'loginOtpSend'])->middleware('throttle:otp')->name('login.otp.send');
    Route::post('/kirish/kod/tasdiq', [AuthController::class, 'loginOtp'])->middleware('throttle:login')->name('login.otp');

    Route::get('/royxatdan-otish', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/royxatdan-otish/kod', [AuthController::class, 'registerOtp'])->middleware('throttle:otp')->name('register.otp');
    Route::post('/royxatdan-otish', [AuthController::class, 'register'])->middleware('throttle:login')->name('register.store');

    Route::get('/parolni-tiklash', [AuthController::class, 'showForgot'])->name('password.forgot');
    Route::post('/parolni-tiklash/kod', [AuthController::class, 'forgotOtp'])->middleware('throttle:otp')->name('password.otp');
    Route::post('/parolni-tiklash', [AuthController::class, 'reset'])->middleware('throttle:login')->name('password.reset');
});
Route::post('/chiqish', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::post('/impersonate/stop', function (\Illuminate\Http\Request $request) {
    $adminId = $request->session()->pull('impersonator_id');
    abort_unless($adminId, 403);
    Auth::loginUsingId($adminId);
    $request->session()->regenerate();

    return redirect()->route('admin.dashboard');
})->middleware('auth')->name('impersonate.stop');

/* ============ Ochiq ariza formasi ============ */
Route::get('/k/{key}', [\App\Http\Controllers\Public\LeadFormController::class, 'show'])->name('lead.form');
Route::post('/k/{key}', [\App\Http\Controllers\Public\LeadFormController::class, 'submit'])->middleware('throttle:public-lead')->name('lead.submit');

/* ============ Tashqi tizimlar (Payme, Eskiz) ============ */
Route::prefix('webhooks')->middleware('throttle:webhooks')->group(function () {
    Route::post('/payme', Webhooks\PaymeController::class)->name('webhooks.payme');
    Route::post('/eskiz', Webhooks\EskizController::class)->name('webhooks.eskiz');
});

/* ============ Bog'cha kabineti ============ */
Route::prefix('app')->name('app.')->middleware(['auth', 'tenant', 'writable'])->group(function () {
    Route::get('/', [AppC\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/stats', [AppC\DashboardController::class, 'stats'])->name('dashboard.stats');
    Route::get('/poll', [NotificationController::class, 'poll'])->name('poll');

    Route::get('/bildirishnomalar', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('/bildirishnomalar/oxirgi', [NotificationController::class, 'recent'])->name('notifications.recent');
    Route::post('/bildirishnomalar/oqildi', [NotificationController::class, 'read'])->name('notifications.read');

    Route::get('/profil', [AppC\ProfileController::class, 'index'])->name('profile.index');
    Route::put('/profil', [AppC\ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profil/parol', [AppC\ProfileController::class, 'password'])->name('profile.password');

    Route::middleware('can:subscription.manage')->prefix('obuna')->name('subscription.')->group(function () {
        Route::get('/', [AppC\SubscriptionController::class, 'index'])->name('index');
        Route::post('/sotib-olish', [AppC\SubscriptionController::class, 'buy'])->name('buy');
        Route::post('/balans/chek', [AppC\SubscriptionController::class, 'topupManual'])->name('topup.manual');
        Route::post('/balans/payme', [AppC\SubscriptionController::class, 'topupPayme'])->name('topup.payme');
        Route::post('/avto-yangilash', [AppC\SubscriptionController::class, 'autoRenew'])->name('auto-renew');
        Route::get('/chek/{topup}', [AppC\SubscriptionController::class, 'receipt'])->name('receipt');
    });

    // CRM bo'limlari alohida fayllarda
    require __DIR__.'/crm.php';
});

/* ============ Super admin ============ */
Route::prefix('admin')->name('admin.')->middleware(['auth', 'super'])->group(function () {
    Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/stats', [Admin\DashboardController::class, 'stats'])->name('dashboard.stats');
    Route::get('/poll', [NotificationController::class, 'poll'])->name('poll');

    Route::get('/bildirishnomalar', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('/bildirishnomalar/oxirgi', [NotificationController::class, 'recent'])->name('notifications.recent');
    Route::post('/bildirishnomalar/oqildi', [NotificationController::class, 'read'])->name('notifications.read');

    Route::get('/bogchalar', [Admin\TenantController::class, 'index'])->name('tenants.index');
    Route::get('/bogchalar/{tenant}', [Admin\TenantController::class, 'show'])->name('tenants.show');
    Route::post('/bogchalar/{tenant}/bepul-muddat', [Admin\TenantController::class, 'grant'])->name('tenants.grant');
    Route::put('/bogchalar/{tenant}/nashr', [Admin\TenantController::class, 'edition'])->name('tenants.edition');
    Route::put('/bogchalar/{tenant}/imkoniyatlar', [Admin\TenantController::class, 'features'])->name('tenants.features');
    Route::post('/bogchalar/{tenant}/blok', [Admin\TenantController::class, 'suspend'])->name('tenants.suspend');
    Route::post('/bogchalar/{tenant}/balans', [Admin\TenantController::class, 'wallet'])->name('tenants.wallet');
    Route::post('/bogchalar/{tenant}/xabar', [Admin\TenantController::class, 'message'])->name('tenants.message');
    Route::post('/bogchalar/{tenant}/kirish', [Admin\TenantController::class, 'impersonate'])->name('tenants.impersonate');
    Route::delete('/bogchalar/{tenant}', [Admin\TenantController::class, 'destroy'])->name('tenants.destroy');

    Route::get('/cheklar', [Admin\TopupController::class, 'index'])->name('topups.index');
    Route::post('/cheklar/{topup}/tasdiqlash', [Admin\TopupController::class, 'approve'])->name('topups.approve');
    Route::post('/cheklar/{topup}/rad-etish', [Admin\TopupController::class, 'reject'])->name('topups.reject');
    Route::get('/cheklar/{topup}/rasm', [Admin\TopupController::class, 'receipt'])->name('topups.receipt');

    Route::get('/tizim', [Admin\SystemController::class, 'index'])->name('system.index');
    Route::get('/tizim/holat', [Admin\SystemController::class, 'data'])->name('system.data');

    Route::get('/tariflar', [Admin\PlanController::class, 'index'])->name('plans.index');
    Route::put('/tariflar/{edition}', [Admin\PlanController::class, 'updateEdition'])->name('plans.update');

    Route::get('/sozlamalar', [Admin\SettingsController::class, 'index'])->name('settings.index');
    Route::put('/sozlamalar', [Admin\SettingsController::class, 'update'])->name('settings.update');
    Route::post('/sozlamalar/eskiz-tekshirish', [Admin\SettingsController::class, 'eskizCheck'])->name('settings.eskiz-check');
    Route::post('/sozlamalar/shablonlar/holat', [Admin\SettingsController::class, 'templatesSync'])->name('settings.templates.sync');
    Route::put('/sozlamalar/shablonlar/{template}', [Admin\SettingsController::class, 'templateUpdate'])->name('settings.templates.update');
    Route::post('/sozlamalar/shablonlar/{template}/yuborish', [Admin\SettingsController::class, 'templateSubmit'])->name('settings.templates.submit');
    Route::post('/sozlamalar/shablonlar/{template}/sinov', [Admin\SettingsController::class, 'templateTest'])->name('settings.templates.test');

    Route::get('/audit', [Admin\AuditController::class, 'index'])->name('audit.index');
});
