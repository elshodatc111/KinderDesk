<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head><?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php echo $__env->yieldPushContent('head'); ?></head>
<body class="bg-cloud" x-data="{ menu: false }">
<header class="sticky top-0 z-40 bg-cloud/90 backdrop-blur border-b border-line">
    <div class="max-w-6xl mx-auto px-4 h-16 flex items-center gap-4">
        <a href="<?php echo e(route('home')); ?>" aria-label="<?php echo e(__('KinderDesk')); ?>"><?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?></a>
        <nav class="hidden md:flex items-center gap-6 ml-8 font-semibold text-sm">
            <a href="<?php echo e(route('home')); ?>#imkoniyatlar" class="hover:text-teal-700"><?php echo __('Imkoniyatlar'); ?></a>
            <a href="<?php echo e(route('home')); ?>#nashrlar" class="hover:text-teal-700"><?php echo __('Nashrlar'); ?></a>
            <a href="<?php echo e(route('home')); ?>#narxlar" class="hover:text-teal-700"><?php echo __('Narxlar'); ?></a>
            <a href="<?php echo e(route('home')); ?>#savollar" class="hover:text-teal-700"><?php echo __('Savollar'); ?></a>
        </nav>
        <div class="ml-auto flex items-center gap-2">
            <?php echo $__env->make('partials.lang-switch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(auth()->user()->is_super_admin ? route('admin.dashboard') : route('app.dashboard')); ?>" class="btn btn-sm btn-primary"><?php echo __('Kabinetga o\'tish'); ?></a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-sm hidden sm:inline-flex"><?php echo __('Kirish'); ?></a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-accent"><?php echo __('14 kun bepul'); ?></a>
            <?php endif; ?>
        </div>
    </div>
</header>
<main><?php echo $__env->yieldContent('content'); ?></main>
<footer class="mt-20 bg-ink text-white/80">
    <div class="max-w-6xl mx-auto px-4 py-10 grid gap-8 md:grid-cols-3">
        <div><?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['size' => 'sm','class' => '[&_*]:!text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','class' => '[&_*]:!text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?><p class="mt-3 text-sm font-semibold text-white/60"><?php echo __('Xususiy bog\'chalar uchun yagona boshqaruv platformasi.'); ?></p></div>
        <div class="text-sm font-medium space-y-2">
            <a class="block hover:text-white" href="<?php echo e(route('legal', 'oferta')); ?>"><?php echo __('Ommaviy oferta'); ?></a>
            <a class="block hover:text-white" href="<?php echo e(route('legal', 'privacy')); ?>"><?php echo __('Maxfiylik siyosati'); ?></a>
            <a class="block hover:text-white" href="<?php echo e(route('legal', 'terms')); ?>"><?php echo __('Foydalanish shartlari'); ?></a>
        </div>
        <div class="text-sm font-medium space-y-2">
            <?php if($p = \App\Models\PlatformSetting::get('support.phone')): ?><p><?php echo __('Tel:'); ?> <?php echo e($p); ?></p><?php endif; ?>
            <?php if($t = \App\Models\PlatformSetting::get('support.telegram')): ?><p><?php echo __('Telegram:'); ?> <?php echo e($t); ?></p><?php endif; ?>
        </div>
    </div>
    <p class="text-center text-xs font-medium text-white/40 pb-6">© <?php echo e(date('Y')); ?> <?php echo __('KinderDesk'); ?></p>
</footer>
<?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/claude/kinderdesk/resources/views/layouts/public.blade.php ENDPATH**/ ?>