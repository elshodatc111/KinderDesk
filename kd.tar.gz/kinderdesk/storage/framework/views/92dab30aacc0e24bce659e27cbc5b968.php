
<div class="relative" x-data="bell(<?php echo \Illuminate\Support\Js::from($bellUrl)->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($readUrl)->toHtml() ?>)" @click.outside="open = false" @kd-activity.window="refresh()">
    <button class="btn btn-sm !px-2.5 relative" @click="toggle()" aria-label="<?php echo e(__('Bildirishnomalar')); ?>" :aria-expanded="open">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'bell']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bell']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <span x-show="$store.live.unread > 0" x-cloak x-text="$store.live.unread > 9 ? '9+' : $store.live.unread"
              class="absolute -top-2 -right-2 min-w-5 h-5 px-1 grid place-items-center rounded-full bg-berry-500 text-white text-[.7rem] font-semibold border border-line"></span>
    </button>
    <div x-show="open" x-cloak x-transition.opacity class="absolute right-0 mt-2 w-[22rem] max-w-[calc(100vw-2rem)] card-sticker z-50 overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-line">
            <p class="font-semibold"><?php echo __('Bildirishnomalar'); ?></p>
            <button class="btn-quiet" @click="readAll()" x-show="$store.live.unread > 0"><?php echo __('Hammasini o\'qilgan qilish'); ?></button>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <template x-if="items.length === 0">
                <p class="px-4 py-8 text-center text-sm font-medium text-ink-mute"><?php echo __('Hozircha yangi xabar yo\'q'); ?></p>
            </template>
            <template x-for="n in items" :key="n.id">
                <a :href="n.url || '#'" class="flex gap-3 px-4 py-3 hover:bg-cloud border-b border-line last:border-0" :class="n.read ? 'opacity-70' : ''">
                    <span class="mt-1 size-2.5 rounded-full flex-none"
                          :class="{'bg-teal-500': n.level==='info'||n.level==='success', 'bg-marigold-500': n.level==='warning', 'bg-danger': n.level==='danger', 'opacity-0': n.read}"></span>
                    <span class="min-w-0">
                        <span class="block text-sm font-semibold leading-snug" x-text="n.title"></span>
                        <span class="block text-xs font-semibold text-ink-soft" x-show="n.body" x-text="n.body"></span>
                        <span class="block text-[.7rem] font-medium text-ink-mute mt-0.5" x-text="n.time"></span>
                    </span>
                </a>
            </template>
        </div>
        <?php if(isset($allUrl)): ?><a href="<?php echo e($allUrl); ?>" class="block text-center py-2.5 text-sm font-semibold text-teal-700 hover:bg-teal-50 border-t border-line"><?php echo __('Barchasini ko\'rish'); ?></a><?php endif; ?>
    </div>
</div>
<?php if (! $__env->hasRenderedOnce('59af4222-31d7-4e41-b5ea-5d55bdde28e6')): $__env->markAsRenderedOnce('59af4222-31d7-4e41-b5ea-5d55bdde28e6'); ?>
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('bell', (url, readUrl) => ({
            open: false, items: [], loaded: false,
            async refresh() { if (this.open || !this.loaded) { await this.load(); } },
            async load() {
                try {
                    const r = await fetch(url, { headers: { Accept: 'application/json' } });
                    if (r.ok) { const j = await r.json(); this.items = j.items; Alpine.store('live').unread = j.unread; this.loaded = true; }
                } catch (e) {}
            },
            async toggle() { this.open = !this.open; if (this.open) await this.load(); },
            async readAll() {
                await fetch(readUrl, { method: 'POST', headers: { 'X-CSRF-TOKEN': window.KD.csrf, Accept: 'application/json' } });
                Alpine.store('live').unread = 0; this.items = this.items.map(i => ({ ...i, read: true }));
            },
        }));
        window.addEventListener('kd:activity', () => window.dispatchEvent(new CustomEvent('kd-activity')));
    });
</script>
<?php endif; ?>
<?php /**PATH /home/claude/kinderdesk/resources/views/partials/bell.blade.php ENDPATH**/ ?>