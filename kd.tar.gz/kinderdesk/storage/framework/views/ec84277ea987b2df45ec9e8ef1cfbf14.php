<?php $__env->startSection('title', 'Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>
<div x-data="liveData('<?php echo e(route('app.dashboard.stats')); ?>', <?php echo \Illuminate\Support\Js::from($stats)->toHtml() ?>)">
    <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <a href="<?php echo e(route('app.kids.index')); ?>" class="tile" style="--tile-bg:var(--color-berry-50);--tile-accent:var(--color-berry-500)">
            <span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'kids']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kids']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><p class="tile-label"><?php echo __('Faol bolalar'); ?></p><p class="tile-value" x-text="data.kids"></p></a>
        <a href="<?php echo e(route('app.groups.index')); ?>" class="tile" style="--tile-bg:var(--color-sky-50);--tile-accent:var(--color-sky-500)">
            <span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'groups']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'groups']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><p class="tile-label"><?php echo __('Guruhlar'); ?></p><p class="tile-value" x-text="data.groups"></p></a>
        <a href="<?php echo e(route('app.employees.index')); ?>" class="tile" style="--tile-bg:var(--color-grape-50);--tile-accent:var(--color-grape-500)">
            <span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'employees']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'employees']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><p class="tile-label"><?php echo __('Xodimlar'); ?></p><p class="tile-value" x-text="data.employees"></p></a>
        <?php if(isset($stats['attendance'])): ?>
        <a href="<?php echo e(route('app.attendance.index')); ?>" class="tile" style="--tile-bg:var(--color-leaf-50);--tile-accent:var(--color-leaf-500)">
            <span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'attendance']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'attendance']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><p class="tile-label"><?php echo __('Bugun kelganlar'); ?></p>
            <p class="tile-value"><span x-text="data.attendance?.present ?? 0"></span><span class="text-base text-ink-mute" x-show="data.attendance?.marked"> / <span x-text="data.attendance?.marked"></span></span></p></a>
        <?php endif; ?>
    </div>

    <?php if(isset($stats['income_month'])): ?>
    <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 mt-4">
        <div class="tile" style="--tile-bg:var(--color-marigold-50);--tile-accent:var(--color-marigold-500)"><span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'wallet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <p class="tile-label"><?php echo __('Shu oy kirim'); ?></p><p class="tile-value"><span x-text="new Intl.NumberFormat('ru-RU').format(data.income_month)"></span> <span class="text-sm"><?php echo __('so\'m'); ?></span></p>
            <p class="text-xs font-medium text-ink-soft mt-1"><?php echo __('Bugun:'); ?> <span x-text="new Intl.NumberFormat('ru-RU').format(data.income_today)"></span></p></div>
        <div class="tile" style="--tile-bg:var(--color-sky-50);--tile-accent:var(--color-sky-500)"><span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'cash']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cash']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <p class="tile-label"><?php echo __('Shu oy chiqim'); ?></p><p class="tile-value"><span x-text="new Intl.NumberFormat('ru-RU').format(data.expense_month)"></span> <span class="text-sm"><?php echo __('so\'m'); ?></span></p></div>
        <a href="<?php echo e(route('app.kids.index', ['debt' => 1])); ?>" class="tile" style="--tile-bg:var(--color-berry-50);--tile-accent:var(--color-danger)"><span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <p class="tile-label"><?php echo __('Jami qarz'); ?></p><p class="tile-value"><span x-text="new Intl.NumberFormat('ru-RU').format(data.debt)"></span> <span class="text-sm"><?php echo __('so\'m'); ?></span></p>
            <p class="text-xs font-medium text-ink-soft mt-1"><span x-text="data.debtors"></span> <?php echo __('ta bola'); ?></p></a>
        <a href="<?php echo e(route('app.finance.index')); ?>" class="tile" style="--tile-bg:var(--color-sun-50);--tile-accent:var(--color-sun-500)"><span class="tile-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <p class="tile-label"><?php echo __('Tasdiq kutayotgan to\'lovlar'); ?></p><p class="tile-value" x-text="data.pending"></p></a>
    </div>

    <div class="grid lg:grid-cols-3 gap-4 mt-6">
        <div class="card card-pad lg:col-span-2">
            <h2 class="section-title mb-3"><?php echo __('Kirim va chiqim (6 oy)'); ?></h2>
            <div class="h-64"><canvas x-init="
                kdChart($el, { type: 'bar', data: { labels: data.chart.labels, datasets: [
                    { label: 'Kirim', data: data.chart.income, backgroundColor: '#008878', borderRadius: 8 },
                    { label: 'Chiqim', data: data.chart.expense, backgroundColor: '#e88810', borderRadius: 8 } ] },
                  options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { y: { ticks: { callback: v => new Intl.NumberFormat('ru-RU', {notation:'compact'}).format(v) } } } } })
                  .then(c => window.addEventListener('kd:activity', () => { c.data.labels = data.chart.labels; c.data.datasets[0].data = data.chart.income; c.data.datasets[1].data = data.chart.expense; c.update(); }))"></canvas></div>
        </div>
        <div class="card card-pad">
            <h2 class="section-title mb-3"><?php echo __('Yaqin tug\'ilgan kunlar'); ?></h2>
            <template x-if="!data.birthdays.length"><p class="text-sm font-medium text-ink-mute"><?php echo __('Bir hafta ichida tug\'ilgan kun yo\'q'); ?></p></template>
            <ul class="space-y-2.5"><template x-for="b in data.birthdays" :key="b.id">
                <li class="flex items-center gap-3"><span class="grid place-items-center size-10 rounded-xl bg-berry-100 text-lg">🎂</span>
                    <span class="min-w-0"><a :href="'<?php echo e(url('app/kids')); ?>/'+b.id" class="block font-semibold truncate hover:underline" x-text="b.name"></a>
                    <span class="text-xs font-medium text-ink-soft"><span x-text="b.date"></span> · <span x-text="b.age"></span> <?php echo __('yosh'); ?></span></span></li></template></ul>
        </div>
    </div>
    <?php else: ?>
    <div class="card card-pad mt-6">
        <h2 class="section-title mb-3"><?php echo __('Yaqin tug\'ilgan kunlar'); ?></h2>
        <template x-if="!data.birthdays.length"><p class="text-sm font-medium text-ink-mute"><?php echo __('Bir hafta ichida tug\'ilgan kun yo\'q'); ?></p></template>
        <ul class="space-y-2"><template x-for="b in data.birthdays" :key="b.id"><li class="font-semibold"><span x-text="b.name"></span> <span class="text-ink-soft text-sm" x-text="b.date"></span></li></template></ul>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/kinderdesk/resources/views/app/dashboard.blade.php ENDPATH**/ ?>