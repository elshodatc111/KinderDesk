<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['size' => 40]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['size' => 40]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 104" width="<?php echo e($size); ?>" height="<?php echo e($size * 104 / 120); ?>" fill="none" role="img" aria-label="<?php echo e(__('KinderDesk')); ?>" <?php echo e($attributes); ?>>
    <path d="M12 20c16-7 34-5 48 5 14-10 32-12 48-5v52c-16-7-34-5-48 5-14-10-32-12-48-5V20Z" stroke="#60c0b0" stroke-width="6" stroke-linejoin="round"/>
    <path d="M10 76c16-7 34-5 50 6 16-11 34-13 50-6" stroke="#008878" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M30 58 44 44l9 8 22-20" stroke="#e88810" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M64 30h12v12" stroke="#e88810" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M28 68c20 7 44 7 64 0" stroke="#e88810" stroke-width="5.5" stroke-linecap="round"/>
</svg>
<?php /**PATH /home/claude/kinderdesk/resources/views/components/logo-mark.blade.php ENDPATH**/ ?>