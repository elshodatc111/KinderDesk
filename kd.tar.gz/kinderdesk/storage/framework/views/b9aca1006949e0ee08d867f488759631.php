
<div x-data="{ show: false }" @kd:confirm-logout.window="show = true" @keydown.escape.window="show = false">
    <div x-show="show" x-cloak class="modal-backdrop" @click.self="show = false" role="dialog" aria-modal="true" aria-labelledby="logout-title">
        <form method="post" action="<?php echo e(route('logout')); ?>" class="modal-panel !max-w-sm text-center space-y-4">
            <?php echo csrf_field(); ?>
            <span class="mx-auto grid place-items-center size-12 rounded-full bg-marigold-50 text-marigold-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <div><h3 id="logout-title" class="text-lg font-semibold"><?php echo e(__('Tizimdan chiqasizmi?')); ?></h3>
                <p class="text-sm text-ink-soft mt-1"><?php echo e(__("Qayta kirish uchun telefon raqam va parol kerak bo'ladi.")); ?></p></div>
            <div class="flex gap-3 justify-center"><button type="button" class="btn" @click="show = false"><?php echo e(__('Qolish')); ?></button><button class="btn btn-primary"><?php echo e(__('Ha, chiqish')); ?></button></div>
        </form>
    </div>
</div>
<?php /**PATH /home/claude/kinderdesk/resources/views/partials/logout-confirm.blade.php ENDPATH**/ ?>