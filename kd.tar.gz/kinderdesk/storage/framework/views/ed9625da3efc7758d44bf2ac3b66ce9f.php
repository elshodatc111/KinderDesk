<?php $__env->startSection('title', 'Tizimga kirish'); ?>
<?php $__env->startSection('lead', "Telefon raqamingiz bilan kiring"); ?>
<?php $__env->startSection('content'); ?>
<div x-data="{
    mode: 'password', phone: '<?php echo e(old('phone')); ?>', sent: false, wait: 0, msg: '', dev: '', busy: false,
    async send() {
        this.busy = true; this.msg = '';
        const r = await fetch('<?php echo e(route('login.otp.send')); ?>', { method: 'POST', headers: {'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN': window.KD?.csrf || document.querySelector('meta[name=csrf-token]').content}, body: JSON.stringify({phone: this.phone}) });
        const j = await r.json().catch(() => ({ok:false, message:'Xatolik. Qayta urinib ko\'ring'}));
        this.msg = j.message; this.dev = j.dev_code || ''; this.sent = !!j.ok;
        if (j.ok) { this.wait = 60; const t = setInterval(() => { if (--this.wait <= 0) clearInterval(t); }, 1000); }
        this.busy = false;
    }
}">
    <div class="tabs mb-5">
        <button type="button" class="tab" :class="mode==='password' && 'is-active'" @click="mode='password'"><?php echo __('Parol bilan'); ?></button>
        <button type="button" class="tab" :class="mode==='otp' && 'is-active'" @click="mode='otp'"><?php echo __('SMS kod bilan'); ?></button>
    </div>

    <form method="post" action="<?php echo e(route('login.attempt')); ?>" x-show="mode==='password'" class="space-y-4"><?php echo csrf_field(); ?>
        <div><label class="label" for="p1"><?php echo __('Telefon raqam'); ?></label>
            <input id="p1" name="phone" x-model="phone" inputmode="tel" autocomplete="username" placeholder="90 123 45 67" class="input" required autofocus>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label" for="pw"><?php echo __('Parol'); ?></label>
            <input id="pw" type="password" name="password" autocomplete="current-password" class="input" required></div>
        <div class="flex items-center justify-between">
            <label class="flex items-center gap-2 text-sm font-medium"><input type="checkbox" name="remember" value="1" class="check"> <?php echo __('Eslab qol'); ?></label>
            <a href="<?php echo e(route('password.forgot')); ?>" class="text-sm font-semibold text-teal-700 hover:underline"><?php echo __('Parolni unutdim'); ?></a>
        </div>
        <button class="btn btn-primary btn-lg btn-block"><?php echo __('Kirish'); ?></button>
    </form>

    <form method="post" action="<?php echo e(route('login.otp')); ?>" x-show="mode==='otp'" x-cloak class="space-y-4"><?php echo csrf_field(); ?>
        <div><label class="label" for="p2"><?php echo __('Telefon raqam'); ?></label>
            <input id="p2" name="phone" x-model="phone" inputmode="tel" placeholder="90 123 45 67" class="input" required></div>
        <button type="button" class="btn btn-block" @click="send()" :disabled="busy || wait>0">
            <span x-text="wait>0 ? 'Qayta yuborish: '+wait+' s' : 'Kod yuborish'"></span></button>
        <p class="help" x-show="msg" x-text="msg"></p>
        <p class="banner banner-info text-sm" x-show="dev" x-cloak><?php echo __('Sinov rejimi. Kod:'); ?> <b x-text="dev"></b></p>
        <div x-show="sent" x-cloak><label class="label" for="c1"><?php echo __('SMS kod'); ?></label>
            <input id="c1" name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" class="input text-center tracking-[.5em] text-xl font-semibold">
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <button class="btn btn-primary btn-lg btn-block" x-show="sent" x-cloak><?php echo __('Kirish'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('below'); ?>
<p class="text-center mt-5 font-medium text-ink-soft"><?php echo __('Hisobingiz yo\'qmi?'); ?> <a href="<?php echo e(route('register')); ?>" class="text-teal-700 font-semibold hover:underline"><?php echo e(config('kinderdesk.trial_days')); ?> <?php echo __('kun bepul boshlang'); ?></a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/kinderdesk/resources/views/auth/login.blade.php ENDPATH**/ ?>