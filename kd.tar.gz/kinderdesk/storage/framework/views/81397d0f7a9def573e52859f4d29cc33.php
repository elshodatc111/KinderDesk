<div class="seg !p-0.5 text-xs" role="group" aria-label="<?php echo e(__('Language')); ?>">
    <?php $__currentLoopData = ['ru' => 'RU', 'uz' => 'UZ']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('locale', $code)); ?>" class="px-2.5 py-1 rounded-md font-semibold <?php echo e(app()->getLocale() === $code ? 'bg-white text-teal-700 shadow-sm' : 'text-ink-soft hover:text-ink'); ?>" hreflang="<?php echo e($code); ?>"><?php echo e(__($label)); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/claude/kinderdesk/resources/views/partials/lang-switch.blade.php ENDPATH**/ ?>