<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="theme-color" content="#008878">
<title><?php echo e(kd_title('KinderDesk')); ?> <?php echo __('— KinderDesk'); ?></title>
<link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php /**PATH /home/claude/kinderdesk/resources/views/partials/head.blade.php ENDPATH**/ ?>