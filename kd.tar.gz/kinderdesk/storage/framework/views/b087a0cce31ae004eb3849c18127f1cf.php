<?php $__env->startSection('title', "Bog'changiz uchun yagona boshqaruv"); ?>
<?php $__env->startSection('content'); ?>


<section class="relative overflow-hidden paper-dots">
    <div class="max-w-6xl mx-auto px-4 pt-14 pb-20 grid lg:grid-cols-[1.1fr_.9fr] gap-12 items-center">
        <div>
            <h1 class="font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.05] text-balance"><?php echo __('Bog\'cha ishi tartibga tushsa, bolalarga vaqt qoladi'); ?></h1>
            <p class="mt-5 text-lg font-semibold text-ink-soft max-w-xl text-pretty"><?php echo __('Bolalar, davomad, to\'lovlar, ish haqi va ota-onalarga SMS — hammasi bitta joyda. Har bir bog\'cha tizimni o\'ziga moslaydi: keraksiz bo\'limni o\'chiradi, kerakligini qo\'shadi.'); ?></p>
            <div class="mt-8 flex flex-wrap gap-3">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-accent btn-lg"><?php echo e($trialDays); ?> <?php echo __('kun bepul sinab ko\'ring'); ?></a>
                <a href="#nashrlar" class="btn btn-lg"><?php echo __('Nashrlarni ko\'rish'); ?></a>
            </div>
            <p class="mt-4 text-sm font-medium text-ink-mute"><?php echo __('Karta shart emas. Sinov tugagach ma\'lumotlaringiz saqlanadi, tizim ko\'rish rejimiga o\'tadi.'); ?></p>
        </div>

        <div class="relative mx-auto w-full max-w-md select-none" aria-hidden="true">
            <?php
                $blocks = [
                    ['Bolalar', 'var(--color-berry-500)', '#fff', '-2deg', '0s', '11rem'],
                    ['Davomad', 'var(--color-leaf-500)', '#1a1a1a', '2deg', '.15s', '13rem'],
                    ["To'lov", 'var(--color-sun-500)', '#1a1a1a', '-1deg', '.3s', '12rem'],
                    ['Ish haqi', 'var(--color-sky-500)', '#fff', '3deg', '.45s', '14rem'],
                    ['SMS', 'var(--color-grape-500)', '#fff', '-3deg', '.6s', '10rem'],
                ];
            ?>
            <div class="flex flex-col-reverse items-center gap-2 pt-6">
                <div class="h-3 w-72 rounded-full bg-ink/80 mt-1"></div>
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$t, $bg, $fg, $rot, $d, $w]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tower-block rounded-2xl border border-line px-5 py-4 text-center font-semibold text-xl"
                         style="--r1:<?php echo e($rot); ?>;--d:<?php echo e($d); ?>;width:<?php echo e($w); ?>;background:<?php echo e($bg); ?>;color:<?php echo e($fg); ?>;box-shadow:4px 4px 0 0 var(--color-ink)"><?php echo e($t); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<section id="imkoniyatlar" class="max-w-6xl mx-auto px-4 py-16 scroll-mt-20">
    <h2 class="font-display text-3xl sm:text-4xl font-semibold max-w-2xl text-balance"><?php echo __('Kundalik ishning hammasi — bitta oynada'); ?></h2>
    <div class="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <?php
            $cards = [
                ['kids', 'berry', 'Bolalar va guruhlar', "Ota-ona ma'lumotlari, guruhga qabul, qarz va to'lov tarixi bir kartada."],
                ['attendance', 'leaf', 'Davomad', "Tarbiyachi telefondan belgilaydi. Internet uzilsa ham saqlanadi va keyin yuboriladi."],
                ['wallet', 'marigold', "Kassa va to'lovlar", "Kim qancha to'ladi, kimda qarz bor — real vaqtda. Har bir so'm hisobda."],
                ['cash', 'sky', 'Ish haqi', "Qat'iy oylik, davomad bo'yicha yoki aralash — bog'changiz usulini tanlang."],
                ['sms', 'grape', 'SMS xabarlar', "O'z Eskiz hisobingiz bilan. Qaysi holatda yuborilishini o'zingiz belgilaysiz."],
                ['inbox', 'sun', 'Arizalar', "Ochiq forma havolasini ulashing — arizalar voronkaga o'zi tushadi."],
            ];
        ?>
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$icon, $color, $title, $text]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-sticker p-6" style="<?php echo e(\App\Support\Navigation::colors($color)); ?>">
                <span class="nav-block !size-12 mb-4"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                <h3 class="text-lg font-semibold"><?php echo e($title); ?></h3>
                <p class="mt-1.5 font-semibold text-ink-soft text-pretty"><?php echo e(__($text)); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<section class="bg-teal-50 border-y-2 border-line">
    <div class="max-w-6xl mx-auto px-4 py-16">
        <h2 class="font-display text-3xl sm:text-4xl font-semibold"><?php echo __('Uch qadamda ishga tushadi'); ?></h2>
        <ol class="mt-10 grid md:grid-cols-3 gap-6">
            <?php $__currentLoopData = [["Ro'yxatdan o'ting", "Telefon raqamingizni SMS kod bilan tasdiqlang va nashrni tanlang."], ["Bog'chani moslang", "Guruhlar, xodimlar, narxlar va kerakli bo'limlarni sozlang."], ["Ishlashni boshlang", "Bolalarni kiriting, davomad va to'lovlarni yuriting."]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$t, $d]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="card p-6 relative">
                    <span class="absolute -top-4 -left-2 grid place-items-center size-10 rounded-full bg-marigold-500 border border-line font-semibold"><?php echo e($i + 1); ?></span>
                    <h3 class="font-semibold text-lg mt-2"><?php echo e($t); ?></h3><p class="font-semibold text-ink-soft mt-1"><?php echo e($d); ?></p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</section>


<section id="nashrlar" class="max-w-6xl mx-auto px-4 py-16 scroll-mt-20" x-data="{ months: 3 }">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h2 class="font-display text-3xl sm:text-4xl font-semibold"><?php echo __('Bog\'changizga mos nashrni tanlang'); ?></h2>
            <p class="mt-2 font-semibold text-ink-soft"><?php echo __('Hammasida'); ?> <?php echo e($trialDays); ?> <?php echo __('kunlik bepul sinov. Nashrni keyin almashtirish mumkin.'); ?></p>
        </div>
        <div class="tabs" id="narxlar" role="tablist" aria-label="<?php echo e(__('Obuna muddati')); ?>">
            <?php $__currentLoopData = [1 => '1 oy', 3 => '3 oy', 12 => '1 yil']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" role="tab" class="tab" :class="months === <?php echo e($m); ?> && 'is-active'" @click="months = <?php echo e($m); ?>" :aria-selected="months === <?php echo e($m); ?>"><?php echo e(__($l)); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="mt-10 grid lg:grid-cols-3 gap-6 items-stretch">
        <?php $__currentLoopData = $editions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $featured = $ed->key === 'standard'; ?>
            <div class="card-sticker p-6 flex flex-col relative <?php echo e($featured ? 'lg:-mt-3 lg:mb-3' : ''); ?>" style="<?php echo e($featured ? 'background:var(--color-sun-50)' : ''); ?>">
                <?php if($featured): ?><span class="badge badge-orange absolute -top-3 right-5"><?php echo __('Ko\'pchilik tanlaydi'); ?></span><?php endif; ?>
                <h3 class="text-2xl font-semibold"><?php echo e(__($ed->name)); ?></h3>
                <p class="font-semibold text-ink-soft mt-1 min-h-12"><?php echo e(__($ed->tagline)); ?></p>
                <div class="mt-5">
                    <?php $__currentLoopData = $ed->plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div x-show="months === <?php echo e($plan->months); ?>" <?php if(!$loop->first): ?> x-cloak <?php endif; ?>>
                            <p class="text-4xl font-semibold tracking-tight"><?php echo e(money($plan->price)); ?> <span class="text-base font-medium text-ink-mute"><?php echo __('so\'m'); ?></span></p>
                            <p class="text-sm font-medium text-ink-soft mt-1"><?php echo e(__($plan->label())); ?> <?php echo __('uchun'); ?>

                                <?php if($plan->months > 1): ?> <?php echo __('· oyiga'); ?> <?php echo e(money($plan->monthlyEquivalent())); ?> <?php echo __('so\'m'); ?> <?php endif; ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <ul class="mt-6 space-y-2 flex-1">
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($f['core']) && false) continue; ?>
                        <?php $has = in_array($key, $ed->features ?? []); ?>
                        <li class="flex items-start gap-2.5 font-medium <?php echo e($has ? '' : 'text-ink-mute line-through decoration-1'); ?>">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $has ? 'check' : 'x','class' => 'size-5 mt-0.5 shrink-0 '.e($has ? 'text-leaf-700' : 'text-ink-mute').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($has ? 'check' : 'x'),'class' => 'size-5 mt-0.5 shrink-0 '.e($has ? 'text-leaf-700' : 'text-ink-mute').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            <span><?php echo e(__($f['label'])); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <a href="<?php echo e(route('register', ['edition' => $ed->key])); ?>" class="btn <?php echo e($featured ? 'btn-accent' : 'btn-primary'); ?> btn-lg btn-block mt-7"><?php echo __('Bepul boshlash'); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <p class="text-sm font-medium text-ink-mute mt-6"><?php echo __('To\'lov Payme yoki karta orqali (chek yuborib). Summa to\'liq bog\'cha balansiga tushadi.'); ?></p>
</section>


<section id="savollar" class="max-w-3xl mx-auto px-4 py-12 scroll-mt-20">
    <h2 class="font-display text-3xl font-semibold mb-6"><?php echo __('Ko\'p beriladigan savollar'); ?></h2>
    <div class="space-y-3" x-data="{ open: 0 }">
        <?php $__currentLoopData = [
            ["Sinov tugagach nima bo'ladi?", "Tizim faqat ko'rish rejimiga o'tadi: ma'lumotlaringiz joyida, lekin yangi yozuv kirita olmaysiz. Obunani faollashtirsangiz, ish davom etadi."],
            ["Ma'lumotlarim boshqa bog'chalarga ko'rinadimi?", "Yo'q. Har bir bog'chaning ma'lumoti butunlay alohida, faqat o'z xodimlaringiz ko'ra oladi."],
            ["Obuna tugashiga oldin ogohlantirasizmi?", "Ha. Tugashiga 3 kun qolganda direktorga ilova ichida va SMS orqali xabar boradi. Balansda mablag' bo'lsa, obuna o'zi yangilanadi."],
            ["Bepul sinovni qayta olsam bo'ladimi?", "Yo'q. Bir telefon raqam, email yoki STIR uchun sinov faqat bir marta beriladi."],
            ["SMS qanday yuboriladi?", "Bog'changiz o'z Eskiz hisobini ulaydi. Qaysi holatda SMS ketishini sozlamalardan belgilaysiz; matnlar Eskiz tasdig'idan o'tgach ishlaydi."],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$q, $a]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <button type="button" class="w-full flex items-center justify-between gap-4 text-left px-5 py-4 font-semibold" @click="open = open === <?php echo e($i + 1); ?> ? 0 : <?php echo e($i + 1); ?>" :aria-expanded="open === <?php echo e($i + 1); ?>">
                    <?php echo e($q); ?> <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','class' => 'size-5 shrink-0 transition',':class' => 'open === '.e($i + 1).' && \'rotate-180\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => 'size-5 shrink-0 transition',':class' => 'open === '.e($i + 1).' && \'rotate-180\'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </button>
                <p x-show="open === <?php echo e($i + 1); ?>" x-cloak class="px-5 pb-4 font-semibold text-ink-soft"><?php echo e($a); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10">
    <div class="card-sticker p-8 sm:p-12 text-center" style="background:var(--color-teal-600);color:#fff;box-shadow:6px 6px 0 0 var(--color-marigold-500)">
        <h2 class="font-display text-3xl sm:text-4xl font-semibold text-balance !text-white"><?php echo __('Bugun boshlang —'); ?> <?php echo e($trialDays); ?> <?php echo __('kun hammasi bepul'); ?></h2>
        <a href="<?php echo e(route('register')); ?>" class="btn btn-accent btn-lg mt-6"><?php echo __('Ro\'yxatdan o\'tish'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/kinderdesk/resources/views/public/home.blade.php ENDPATH**/ ?>