<?php $__env->startSection('title', "Bog'chani ro'yxatdan o'tkazing"); ?>
<?php $__env->startSection('lead', config('kinderdesk.trial_days')." kun bepul. Karta kerak emas."); ?>
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('register.store')); ?>" class="space-y-6"
      x-data="{
        phone: <?php echo \Illuminate\Support\Js::from(old('phone', ''))->toHtml() ?>, email: <?php echo \Illuminate\Support\Js::from(old('email', ''))->toHtml() ?>, tax: <?php echo \Illuminate\Support\Js::from(old('tax_id', ''))->toHtml() ?>,
        sent: <?php echo e($errors->has('code') ? 'true' : 'false'); ?>, wait: 0, msg: '', ok: true, dev: '', busy: false,
        async send() {
            this.busy = true; this.msg = '';
            const r = await fetch('<?php echo e(route('register.otp')); ?>', { method: 'POST', headers: {'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content}, body: JSON.stringify({phone: this.phone, email: this.email, tax_id: this.tax}) });
            const j = await r.json().catch(() => ({ok:false, message:'Xatolik. Qayta urinib ko\'ring'}));
            this.msg = j.message || (j.errors ? Object.values(j.errors)[0][0] : ''); this.ok = !!j.ok; this.dev = j.dev_code || ''; this.sent = this.sent || !!j.ok;
            if (j.ok) { this.wait = 60; const t = setInterval(() => { if (--this.wait <= 0) clearInterval(t); }, 1000); }
            this.busy = false;
        }
      }"><?php echo csrf_field(); ?>

    <fieldset>
        <legend class="section-title mb-3"><?php echo __('Nashrni tanlang'); ?></legend>
        <div class="grid sm:grid-cols-3 gap-3">
            <?php $__currentLoopData = $editions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="cursor-pointer">
                    <input type="radio" name="edition" value="<?php echo e($ed->key); ?>" class="peer sr-only" <?php if(old('edition', $selected) === $ed->key): echo 'checked'; endif; ?>>
                    <span class="block h-full rounded-2xl border border-line bg-white p-4 transition peer-checked:border-teal-500 peer-checked:bg-teal-50 peer-checked:ring-2 peer-checked:ring-teal-100 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-teal-500">
                        <span class="block font-semibold text-lg"><?php echo e(__($ed->name)); ?></span>
                        <span class="block text-sm font-semibold text-ink-soft"><?php echo e(__($ed->tagline)); ?></span>
                    </span>
                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php $__errorArgs = ['edition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </fieldset>

    <div class="grid sm:grid-cols-2 gap-4">
        <div class="sm:col-span-2"><label class="label"><?php echo __('Bog\'cha nomi'); ?></label>
            <input name="name" value="<?php echo e(old('name')); ?>" class="input" required placeholder="<?php echo e(__('Masalan: Quyoshli bog\'cha')); ?>"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label"><?php echo __('Direktor ismi'); ?></label>
            <input name="owner_name" value="<?php echo e(old('owner_name')); ?>" class="input" required autocomplete="name"><?php $__errorArgs = ['owner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label"><?php echo __('Telefon raqam'); ?></label>
            <input name="phone" x-model="phone" class="input" inputmode="tel" placeholder="90 123 45 67" required autocomplete="tel"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label"><?php echo __('Email'); ?> <span class="font-semibold text-ink-mute"><?php echo __('(ixtiyoriy)'); ?></span></label>
            <input type="email" name="email" x-model="email" class="input" autocomplete="email"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label"><?php echo __('STIR'); ?> <span class="font-semibold text-ink-mute"><?php echo __('(ixtiyoriy)'); ?></span></label>
            <input name="tax_id" x-model="tax" class="input" inputmode="numeric" maxlength="14"></div>
        <div><label class="label"><?php echo __('Viloyat'); ?></label><input name="region" value="<?php echo e(old('region')); ?>" class="input"></div>
        <div><label class="label"><?php echo __('Shahar / tuman'); ?></label><input name="city" value="<?php echo e(old('city')); ?>" class="input"></div>
        <div><label class="label"><?php echo __('Parol'); ?></label>
            <input type="password" name="password" class="input" autocomplete="new-password" required>
            <p class="help"><?php echo __('Kamida 8 belgi: harf va raqam'); ?></p><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div><label class="label"><?php echo __('Parolni takrorlang'); ?></label>
            <input type="password" name="password_confirmation" class="input" autocomplete="new-password" required></div>
    </div>

    <div class="card p-4 bg-teal-50 space-y-3">
        <p class="font-semibold"><?php echo __('Telefon raqamni tasdiqlang'); ?></p>
        <div class="flex flex-wrap gap-3 items-start">
            <button type="button" class="btn" @click="send()" :disabled="busy || wait>0"><span x-text="wait>0 ? 'Qayta yuborish: '+wait+' s' : (sent ? 'Kodni qayta yuborish' : 'SMS kod yuborish')"></span></button>
            <input name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="000000" class="input !w-40 text-center tracking-[.4em] text-lg font-semibold" :disabled="!sent">
        </div>
        <p class="text-sm font-medium" :class="ok ? 'text-ink-soft' : 'text-danger'" x-show="msg" x-text="msg"></p>
        <p class="banner banner-info text-sm" x-show="dev" x-cloak><?php echo __('Sinov rejimi. Kod:'); ?> <b x-text="dev"></b></p>
        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <label class="flex items-start gap-3 font-semibold">
        <input type="checkbox" name="agree" value="1" class="check mt-1" <?php if(old('agree')): echo 'checked'; endif; ?>>
        <span><a target="_blank" href="<?php echo e(route('legal', 'oferta')); ?>" class="underline font-semibold"><?php echo __('Ommaviy oferta'); ?></a> <?php echo __('va'); ?> <a target="_blank" href="<?php echo e(route('legal', 'privacy')); ?>" class="underline font-semibold"><?php echo __('maxfiylik siyosati'); ?></a> <?php echo __('bilan roziman'); ?></span>
    </label>
    <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button class="btn btn-accent btn-lg btn-block"><?php echo __('Sinovni boshlash'); ?></button>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('below'); ?><p class="text-center mt-5 font-medium text-ink-soft"><?php echo __('Hisobingiz bormi?'); ?> <a href="<?php echo e(route('login')); ?>" class="text-teal-700 font-semibold hover:underline"><?php echo __('Kirish'); ?></a></p><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['wide' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/kinderdesk/resources/views/auth/register.blade.php ENDPATH**/ ?>