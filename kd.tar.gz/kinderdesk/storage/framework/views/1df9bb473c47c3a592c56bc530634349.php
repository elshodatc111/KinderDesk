<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['size' => 'md', 'mark' => true, 'class' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['size' => 'md', 'mark' => true, 'class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $text = ['sm' => 'text-lg', 'md' => 'text-2xl', 'lg' => 'text-4xl'][$size] ?? 'text-2xl';
    $icon = ['sm' => 28, 'md' => 38, 'lg' => 56][$size] ?? 38;
?>
<span <?php echo e($attributes->merge(['class' => "inline-flex items-center gap-2 $class"])); ?>>
    <?php if($mark): ?><?php if (isset($component)) { $__componentOriginal4383542ad8210ed40ff2e701a8552b53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4383542ad8210ed40ff2e701a8552b53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo-mark','data' => ['size' => $icon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $attributes = $__attributesOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $component = $__componentOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__componentOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?><?php endif; ?>
    <span class="font-brand font-semibold tracking-tight leading-none <?php echo e($text); ?>"><span class="text-teal-500"><?php echo __('Kinder'); ?></span><span class="text-marigold-500"><?php echo __('Desk'); ?></span></span>
</span>
<?php /**PATH /home/claude/kinderdesk/resources/views/components/logo.blade.php ENDPATH**/ ?>