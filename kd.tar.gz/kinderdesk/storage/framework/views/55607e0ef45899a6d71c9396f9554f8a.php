<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head><?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php echo $__env->yieldPushContent('head'); ?></head>
<body class="bg-cloud min-h-screen">
<div class="fixed top-4 right-4 z-10"><?php echo $__env->make('partials.lang-switch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<div class="min-h-screen grid place-items-center px-4 py-10">
    <div class="w-full <?php echo e($wide ?? false ? 'max-w-2xl' : 'max-w-md'); ?>">
        <a href="<?php echo e(route('home')); ?>" class="flex justify-center mb-6" aria-label="<?php echo e(__('KinderDesk')); ?>"><?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?></a>
        <div class="card p-6 sm:p-8 !shadow-[0_8px_28px_rgb(16_40_36/.08)]">
            <h1 class="text-2xl font-semibold mb-1"><?php echo e(kd_title()); ?></h1>
            <?php if (! empty(trim($__env->yieldContent('lead')))): ?><p class="text-ink-soft font-semibold mb-5"><?php echo e(__(html_entity_decode(trim(View::yieldContent('lead')), ENT_QUOTES))); ?></p><?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('below'); ?>
    </div>
</div>
<?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/claude/kinderdesk/resources/views/layouts/auth.blade.php ENDPATH**/ ?>